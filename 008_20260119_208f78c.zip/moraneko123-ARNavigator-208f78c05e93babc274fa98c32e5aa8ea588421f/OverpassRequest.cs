using SimpleJSON;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using Google.XR.ARCoreExtensions.Samples.Geospatial;

public class OverpassRequest : MonoBehaviour
{
    public static OverpassRequest instance { get; private set; }

    public OSRMRouteRequest routeRequest;
    public TargetRenderer targetRenderer;

    public static MapTileUI mapTileUI { get; private set; }

    private void Awake()
    {
        if (instance == null) {
            instance = this;
        } else {
            Destroy(gameObject); 
        }
    }

    /// <summary>
    /// �I�[�P�X�g���[�^�F���ݒn����Ŋ�蓹�H�m�[�h���擾���A
    /// ���̃m�[�h����Ŋ��o�X����擾���A���ʂ�\���E���[�g�擾����B
    /// </summary>
    public IEnumerator FetchBusStopInfoCoroutine(double latitude, double longitude)
    {
        double roadLat = latitude, roadLon = longitude;

        // 1) ���ݒn����Ŋ�蓹�H�m�[�h���擾
        yield return StartCoroutine(FetchNearestRoadNodeCoroutine(latitude, longitude, (rLat, rLon) =>
        {
            roadLat = rLat;
            roadLon = rLon;
        }));

        // 2) ���̓��H�m�[�h����Ŋ��̃o�X����擾
        bool foundBus = false;
        string busName = "���O�Ȃ�";
        double busLat = 0, busLon = 0, busDist = 0, busDir = 0;

        yield return StartCoroutine(FetchNearestBusStopFromNodeCoroutine(roadLat, roadLon, (bLat, bLon, name, dist, dir) =>
        {
            foundBus = true;
            busLat = bLat;
            busLon = bLon;
            busName = name;
            busDist = dist;
            busDir = dir;
        }));

        if (!foundBus)
        {
            // �o�X�₪������Ȃ��ꍇ�͂����ŏI���iFetchNearestBusStop... ���ŕ\���ς݁j
            yield break;
        }

        // 3) ���ʂ�p���ĕ\���E���[�g�E�n�}�ǂݍ��݂Ȃǂ��s��
        yield return StartCoroutine(HandleBusStopAndRouteCoroutine(roadLat, roadLon, busLat, busLon, busName, busDist, busDir));
    }

    /// <summary>
    /// �w��ʒu����Ŋ��̓��H�m�[�h(lat, lon) ���擾���� onComplete �ɕԂ��B
    /// �m�[�h��������Ȃ���΁A���̍��W��Ԃ��B
    /// </summary>
    public IEnumerator FetchNearestRoadNodeCoroutine(double latitude, double longitude, Action<double, double> onComplete)
    {
        string roadQuery = $@"
        [out:json];
        node(around:200,{latitude},{longitude})[""highway""];
        out body;";

        var form = new WWWForm();
        form.AddField("data", roadQuery);

        if (targetRenderer != null)
        {
            targetRenderer.AppendApiLog($"Overpass request payload:\n{roadQuery}");
        }

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();

            long responseCode = www.responseCode;
            string responseBody = www.downloadHandler != null ? www.downloadHandler.text : string.Empty;

            if (www.result != UnityWebRequest.Result.Success)
            {
                string err = "API�G���[: " + www.error;
                Debug.LogError(err);

                if (targetRenderer != null)
                {
                    string full = $"Overpass ERROR\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nError: {www.error}\nBody:\n{responseBody}";
                    targetRenderer.AppendApiLog(full);
                    targetRenderer.Display(err);
                }

                // �m�[�h�����Ȃ���Ό����W��Ԃ�
                onComplete?.Invoke(latitude, longitude);
                yield break;
            }

            if (targetRenderer != null)
            {
                string full = $"Overpass RESPONSE\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nBody:\n{responseBody}";
                targetRenderer.AppendApiLog(full);
            }

            var parsed = JSON.Parse(responseBody);
            var roads = parsed["elements"];

            if (roads == null || roads.Count == 0)
            {
                // ������Ȃ��ꍇ�͌��̍��W��Ԃ�
                onComplete?.Invoke(latitude, longitude);
                yield break;
            }

            double bestDistSq = double.MaxValue;
            double bestLat = latitude;
            double bestLon = longitude;

            for (int i = 0; i < roads.Count; i++)
            {
                double rlat = roads[i]["lat"];
                double rlon = roads[i]["lon"];

                double distSq = GeoCalculator.GetDistanceSquared(latitude, longitude, rlat, rlon);
                if (distSq < bestDistSq)
                {
                    bestDistSq = distSq;
                    bestLat = rlat;
                    bestLon = rlon;
                }
            }

            onComplete?.Invoke(bestLat, bestLon);
        }
    }

    /// <summary>
    /// �w��m�[�h�ʒu����Ŋ��̃o�X��(lat, lon, name, distanceMeters, direction) ���擾���� onComplete �ɕԂ��B
    /// ������Ȃ��ꍇ�� targetRenderer �Ƀ��b�Z�[�W��\�����ďI������B
    /// </summary>
    public IEnumerator FetchNearestBusStopFromNodeCoroutine(double nodeLat, double nodeLon, Action<double, double, string, double, double> onComplete)
    {
        // �N�G���g�ݗ��āi�m�[�h���ӂ���o�X���T���j
        string query = $@"
        [out:json];
        node(around:2000,{nodeLat},{nodeLon})[highway=bus_stop];
        out body;";

        var form = new WWWForm();
        form.AddField("data", query);

        if (targetRenderer != null)
        {
            targetRenderer.AppendApiLog($"Overpass request payload:\n{query}");
        }

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();

            long responseCode = www.responseCode;
            string responseBody = www.downloadHandler != null ? www.downloadHandler.text : string.Empty;

            if (www.result != UnityWebRequest.Result.Success)
            {
                string err = "API�G���[: " + www.error;
                Debug.LogError(err);

                if (targetRenderer != null)
                {
                    string full = $"Overpass ERROR\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nError: {www.error}\nBody:\n{responseBody}";
                    targetRenderer.AppendApiLog(full);
                    targetRenderer.Display(err);
                }
                yield break;
            }

            if (targetRenderer != null)
            {
                string full = $"Overpass RESPONSE\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nBody:\n{responseBody}";
                targetRenderer.AppendApiLog(full);
            }

            var parsed = JSON.Parse(responseBody);
            var elements = parsed["elements"];

            if (elements == null || elements.Count == 0)
            {
                if (targetRenderer != null)
                    targetRenderer.Display("�߂��Ƀo�X�₪������܂���B");
                yield break;
            }

            double nearestDistSq = double.MaxValue;
            string nearestName = "���O�Ȃ�";
            double nearestLat = 0, nearestLon = 0;

            for (int i = 0; i < elements.Count; i++)
            {
                var node = elements[i];
                double lat = node["lat"];
                double lon = node["lon"];

                string name = "���O�Ȃ�";
                if (node["tags"] != null && node["tags"]["name"] != null)
                    name = node["tags"]["name"];

                double distSq = GeoCalculator.GetDistanceSquared(nodeLat, nodeLon, lat, lon);
                if (distSq < nearestDistSq)
                {
                    nearestDistSq = distSq;
                    nearestName = name;
                    nearestLat = lat;
                    nearestLon = lon;
                }
            }

            double nearestDist = GeoCalculator.GetDistance(nodeLat, nodeLon, nearestLat, nearestLon);
            double nearestDir = GeoCalculator.GetDirection(nodeLat, nodeLon, nearestLat, nearestLon);

            // callback �Ɍ��ʂ�Ԃ�
            onComplete?.Invoke(nearestLat, nearestLon, nearestName, nearestDist, nearestDir);
        }
    }

    /// <summary>
    /// �擾�ς݂̓��H�m�[�h�ʒu�ƃo�X��ʒu����я����g���ĕ\���E���[�g�擾�E�n�}�ǂݍ��݂��s���B
    /// roadLat/roadLon �͓��H�m�[�h�i�o�x�E�ܓx�̏��œ����g�p����ӏ��ɒ��Ӂj
    /// </summary>
    public IEnumerator HandleBusStopAndRouteCoroutine(double roadLat, double roadLon, double busLat, double busLon, string name, double distanceMeters, double direction)
    {
        // ���[�g�擾�istart: road, end: bus�j
        if (routeRequest != null)
        {
            // OSRM/Graph �Ăяo���� lon, lat �̏������҂���邽�ߒ���
            yield return StartCoroutine(routeRequest.RequestRouteAndPlace(roadLon, roadLat, busLon, busLat));
        }

        // GeospatialController �ɖړI�n��z�u�i�o�x, �ܓx �̏��j
        var geoCtrl = UnityEngine.Object.FindFirstObjectByType<Google.XR.ARCoreExtensions.Samples.Geospatial.GeospatialController>();
        if (geoCtrl != null)
        {
            geoCtrl.PlaceDestinationFromLatLon(roadLon, roadLat, double.NaN, direction);
        }

        if (targetRenderer != null)
        {
            targetRenderer.DisplayBusStop(
                roadLat,
                roadLon,
                name,
                distanceMeters,
                direction,
                busLat,
                busLon);

            if (routeRequest != null)
            {
                if (mapTileUI != null)
                {
                    yield return StartCoroutine(mapTileUI.LoadMapTile(roadLat, roadLon));
                }
                yield return StartCoroutine(routeRequest.RequestRouteAndPlace(roadLon, roadLat, busLon, busLat));
            }
        }
    }
}