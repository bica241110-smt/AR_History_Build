﻿//using UnityEngine;
//using UnityEngine.XR.ARCore;
//using UnityEngine.XR.ARFoundation;

//public class ARAutoReset : MonoBehaviour
//{
//    public ARSession arSession; // インスペクタでARSessionコンポーネントをアサインする
//    public float timeoutSeconds = 10f;
//    float timer;
//    private bool isResetting = false; // リセット実行中のフラグ

//    // OnDisable/OnDestroy で安全にデリゲートを解除
//    private void OnDisable()
//    {
//        // 処理の途中で無効化された場合に備えて解除を試みる
//        ARSession.stateChanged -= OnStateChanged;
//    }

//    void Update()
//    {
//        // リセット処理中は何もせず抜ける
//        if (isResetting) return;

//        // トラッキング中であればタイマーをリセットして抜ける
//        if (ARSession.state == ARSessionState.SessionTracking)
//        {
//            timer = 0f;
//            return;
//        }

//        // サービスが利用可能だがトラッキングできていない状態（Ready, NotTrackingなど）でのみタイマーを進める
//        if (ARSession.state != ARSessionState.None &&
//            ARSession.state != ARSessionState.Installing)
//        {
//            timer += Time.deltaTime;
//        }
//        else // 上記以外はタイマーをリセット
//        {
//            timer = 0f;
//        }

//        if (timer > timeoutSeconds)
//        {
//            timer = 0f;
//            isResetting = true; // リセットを開始
//            StartCoroutine(ResetSession());
//        }
//    }
//    IEnumerator ResetSession()
//    {
//        // 💡 修正点: インスタンス（arSession）を通してReset()を呼び出す
//        if (arSession != null)
//        {
//            // デリゲートの登録はインスタンスが存在する場合のみ行う
//            arSession.stateChanged += OnStateChanged;
//            arSession.Reset(); // ✅ 正しい呼び出し方
//        }

//        yield return null;
//    }

//    void OnStateChanged(ARSessionStateChangedEventArgs args)
//    {
//        // トラッキングが復帰した場合
//        if (args.state == ARSessionState.SessionTracking)
//        {
//            ARSession.stateChanged -= OnStateChanged;
//            isResetting = false; // フラグを解除し、Updateを再開
//            Debug.Log("AR Session Reset Succeeded and Tracking Resumed.");
//        }
//        // リセット後に致命的なエラーが発生した場合もフラグを解除してUpdateを再開する必要がある
//        else if (args.state == ARSessionState.None || args.state == ARSessionState.SessionInitializing)
//        {
//            // 正常なリセット/再初期化の過程。特に何もしない
//        }
//        else if (args.state == ARSessionState.Error)
//        {
//            ARSession.stateChanged -= OnStateChanged;
//            isResetting = false; // エラー終了。Updateを再開して再試行を待つ
//            Debug.LogError("AR Session Reset Failed with Error State.");
//        }
//    }
//}