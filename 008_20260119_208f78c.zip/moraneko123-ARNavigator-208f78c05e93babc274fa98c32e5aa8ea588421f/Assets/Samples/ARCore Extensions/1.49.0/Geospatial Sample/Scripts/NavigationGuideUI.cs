using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class NavigationGuideUI : MonoBehaviour
{
    // --- 1. 方向を定義するEnum ---
    public enum NavSignType
    {
        DiagonalLeft = -3,
        LeftTurn = -2,
        LeftDirection = -1,
        None = 0,
        RightDirection = 1,
        RightTurn = 2,
        DiagonalRight = 3,
        Destination = 4
    }

    // --- 2. 距離の閾値を管理する設定 ---
    [Serializable]
    public struct DistanceThresholds
    {
        public float Far;    // 500m
        public float Middle; // 300m
        public float Near;   // 100m
        public float Nearby;   // 100m
        public float AudioBuffer; // 50m (音声再生判定の遊び)
    }

    [Header("Transparency Settings")]
    [Tooltip("走行中に透明化したいパネルをここにすべて入れてください")]
    [SerializeField] private CanvasGroup[] fadeTargetPanels;

    [Header("Always Visible Panels")]
    [SerializeField] private GameObject infoPanel;  // 常に表示
    [SerializeField] private GameObject arrowPanel; // 常に表示

    // 特定のロジックで個別に制御が必要なパネルは、参照を保持しておきます
    [Header("Individual Panel References")]
    [SerializeField] private GameObject guidePanel;
    [SerializeField] private GameObject mapPanel;
    [SerializeField] private GameObject debugPanel;
    [SerializeField] private GameObject ARviewPanel;

    [Header("References")]
    [SerializeField] private RouteProgressMonitor progressMonitor; // 監視クラスへの参照
    // [SerializeField] private RectTransform arrowIcon;              // 回転させる矢印画像 (UI)
    [SerializeField] private TextMeshProUGUI targetText;      // 目的地表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI distanceText;    // 距離表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI timeText;   // 時刻表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI warnText;   // 警告表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI researchText; // 再検索メッセージ表示テキスト (UI)

    [Header("Speed Display")]
    [SerializeField] private SpeedCalculator SpeedCalculator; // 計算クラスへの参照
    [SerializeField] private TextMeshProUGUI speedText;       // 速度を表示するUI

    [Header("Safety Settings")]
    [SerializeField] private float safetySpeedThreshold = 20.0f; // 閾値
    [SerializeField] private float timeToFade = 3.0f;            // 持続時間
    [SerializeField] private float fadedAlpha = 0.3f;            // 半透明時のアルファ
    [SerializeField] private float fadeSpeed = 5.0f;             // フェード速度

    [Header("Debug Settings")]
    [SerializeField] private Button DebugButton; // デバッグパネル表示切替ボタン

    [Header("Update Settings")]
    [SerializeField] private float uiUpdateInterval = 0.5f; // 更新間隔
    private float _uiUpdateTimer = 0f;

    [Header("Navigation Settings")]
    [SerializeField]
    private DistanceThresholds thresholds = new DistanceThresholds
    {
        Far = 500f,
        Middle = 300f,
        Near = 100f,
        AudioBuffer = 50f
    };

    [SerializeField] private TextMeshProUGUI nextTurnText; // "300m先 右方向"
    [Header("Turn Icons")]
    [SerializeField] private GameObject leftTurnArrow;  // 左曲がり用の画像
    [SerializeField] private GameObject rightTurnArrow; // 右曲がり用の画像

    [Header("Audio Settings")]
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip infoSEClip;   // ポーン
    [SerializeField] private AudioClip FarCallClip;   // 500m先、
    [SerializeField] private AudioClip MiddleCallClip;   // 300m先、
    [SerializeField] private AudioClip nearCallClip;   // この先、
    [SerializeField] private AudioClip leftTurnClip;   // 左方向です
    [SerializeField] private AudioClip rightTurnClip;  // 右方向です
    [SerializeField] private AudioClip goalClip; //目的地が近付いています
    [SerializeField] private AudioClip negiraiClip; //ナビを終了します　おつかれさま

    private int _lastVoiceInstructionIndex = -1; // 音声の重複再生防止用
    private int _lastDistanceCall = -1; // 500, 300, 200 などの距離コール重複防止

    private Coroutine _currentGuidanceCoroutine;
    private float _lastPlayTime = 0f;
    private const float PlayCooldown = 2.0f; // 2秒間は次の案内を流さない

    public bool isDebugPanelVisible { get; private set; } = false;

    private Camera _mainCamera;
    private float _highSpeedTimer = 0f;

    private void Start()
    {
        if (Camera.main != null)
        {
            _mainCamera = Camera.main;
        }

        // --- 追記：ボタンのクリックイベントを登録 ---
        if (DebugButton != null)
        {
            DebugButton.onClick.AddListener(ToggleDebugPanels);
            DebugButton.gameObject.SetActive(false);
        }

        if (arrowPanel != null)
        {
            arrowPanel.SetActive(false);
        }

        // 初期状態を反映（起動時は非表示にする場合）
        SetDebugPanelsVisible(isDebugPanelVisible);
        UpdateTimeDisplay();
    }

    private void Update()
    {
        bool isNavigating = (progressMonitor != null && progressMonitor.IsNavigating);
        if (mapPanel != null && mapPanel.activeSelf != isNavigating)
        {
            mapPanel.SetActive(isNavigating);
        }
        //if (guidePanel != null && mapPanel != null && guidePanel.activeSelf != isNavigating && mapPanel.activeSelf != isNavigating)
        //{
        //    guidePanel.SetActive(isNavigating);
        //    if (targetText != null) targetText.text = $"目的地: {progressMonitor.DestinationName}";
        //}
        if (guidePanel != null && guidePanel.activeSelf != isNavigating)
        {
            guidePanel.SetActive(isNavigating);
            if (isNavigating && targetText != null)
            {
                targetText.text = $"目的地: {progressMonitor.DestinationName}";
            }
        }

        if (!isNavigating) return;

        // 2. 安全フェード処理（滑らかさのため毎フレーム）
        HandleSafetyFade();

    }

    private void HandleSafetyFade()
    {
        if (SpeedCalculator == null) return;

        // SpeedCalculatorから現在の速度(float)を取得
        float currentKmh = SpeedCalculator.CurrentKmh;

        // 速度判定
        if (currentKmh > safetySpeedThreshold)
        {
            _highSpeedTimer += Time.deltaTime;
        }
        else
        {
            _highSpeedTimer = 0f;
        }

        // フェード処理
        bool isDangerSpeed = (_highSpeedTimer >= timeToFade);
        float targetAlpha = isDangerSpeed ? fadedAlpha : 1.0f;
        //uiCanvasGroup.alpha = Mathf.Lerp(uiCanvasGroup.alpha, targetAlpha, Time.deltaTime * fadeSpeed);
        //uiCanvasGroup.blocksRaycasts = !isDangerSpeed;

        // インスペクタで登録したパネルだけをループで回して処理
        foreach (var panelGroup in fadeTargetPanels)
        {
            if (panelGroup == null) continue;

            // 滑らかにフェード
            panelGroup.alpha = Mathf.Lerp(panelGroup.alpha, targetAlpha, Time.deltaTime * fadeSpeed);
        
            // 透明時はボタンなどを押せないようにする
            panelGroup.blocksRaycasts = (panelGroup.alpha > 0.8f);
        }
    }

    /// <summary>
    /// 精度状態を更新し、変化があった場合のみUIを切り替える
    /// </summary>
    public void UpdateAccuracyDisplay(bool isAccurate, bool isTracking)
    {
        if (warnText != null)
        {
            // トラッキング中で、かつ精度が低い場合のみ警告を表示
            if (isTracking && isAccurate)
            {
                warnText.gameObject.SetActive(false);
            }
            else
            {
                warnText.text = $"<color=yellow>精度が不足しています。周囲を見回してください。</color>";
                warnText.gameObject.SetActive(true);
            }
        }
    }

    // 再検索状態の表示を切り替えるメソッド
    public void UpdateReSearchingDisplay(bool isSearching)
    {
        if (researchText == null) return;

        if (isSearching)
        {
            // researchText.text = "<color=orange>ルートから外れました。再検索しています...</color>";
            researchText.gameObject.SetActive(true);

            // 再検索中は距離表示などを一時的に隠す、またはグレーアウトするのも親切です
            if (distanceText != null) distanceText.alpha = 0.5f;
        }
        else
        {
            researchText.gameObject.SetActive(false);
            if (distanceText != null) distanceText.alpha = 1.0f;
        }
    }

    // --- 追記：表示・非表示を切り替えるメソッド ---
    public void ToggleDebugPanels()
    {
        // 状態を反転
        isDebugPanelVisible = !isDebugPanelVisible;

        // パネルの表示状態を更新
        SetDebugPanelsVisible(isDebugPanelVisible);
    }

    private void SetDebugPanelsVisible(bool visible)
    {
        if (debugPanel != null) debugPanel.SetActive(visible);
        if (ARviewPanel != null) ARviewPanel.SetActive(visible);

        // ボタンのテキストや色を変えたい場合はここに追記
        // 例: DebugButton.GetComponentInChildren<TextMeshProUGUI>().text = visible ? "Hide Debug" : "Show Debug";
    }

    public void UpdateDistanceDisplay(float distanceInMeters)
    {
        if (distanceText == null) return;

        if (distanceInMeters >= 1000f)
        {
            // 1km以上は「1.2 km」のように表示
            float distanceInKm = distanceInMeters / 1000f;
            distanceText.text = $"{distanceInKm:F1} km";
        }
        else
        {
            // 1km未満は「350 m」のように表示
            distanceText.text = $"{Mathf.CeilToInt(distanceInMeters)} m";
        }
    }

    public void UpdateTimeDisplay()
    {
        if (timeText != null)
        {
            // "14:30" 形式で表示
            timeText.text = DateTime.Now.ToString("HH:mm");
        }
    }

    public void UpdateTurnInstruction(string text, int signValue, float distance, int index)
    {
        if (nextTurnText == null) return;

        NavSignType sign = (NavSignType)signValue;

        // --- 1. 500m以上離れている場合は案内を隠す ---
        if (distance > thresholds.Far)
        {
            nextTurnText.text = "";
            if (leftTurnArrow != null) leftTurnArrow.SetActive(false);
            if (rightTurnArrow != null) rightTurnArrow.SetActive(false);
            return;
        }

        // --- 2. 段階的なテキスト決定 ---
        string distStr;
        if (distance > thresholds.Middle) distStr = "500m";      // 300~500m
        else if (distance > thresholds.Near) distStr = "300m";   // 100~300m
        else distStr = "この";                                   // 0~100m

        // --- 3. アイコンとテキストの表示 ---
        // if (leftTurnArrow != null) leftTurnArrow.SetActive(sign < 0);
        // if (rightTurnArrow != null) rightTurnArrow.SetActive(sign > 0 && sign != NavSignType.Destination);

        //string directionName = GetDirectionName(sign);
        //if (!string.IsNullOrEmpty(directionName))
        //{
        //    nextTurnText.text = $"{distStr}先、{directionName}です";
        //}
        //if (!string.IsNullOrEmpty(directionName))
        //{
        //    nextTurnText.text = $"{distStr}先、{directionName}です";
        //}
        //else
        //{
        //    // 方向がない場合（Noneなど）はテキストを消すか、距離だけ出すなど
        //    if (sign == NavSignType.Destination) nextTurnText.text = $"{distStr}先、目的地です";
        //    else nextTurnText.text = "";
        //}

        // 音声処理へ
        HandleVoiceGuidance(signValue, distance, index);
    }

    private string GetDirectionName(NavSignType sign)
    {
        return sign switch
        {
            NavSignType.DiagonalLeft => "斜め左",
            NavSignType.LeftTurn => "左折",
            NavSignType.LeftDirection => "左方向",
            NavSignType.DiagonalRight => "斜め右",
            NavSignType.RightTurn => "右折",
            NavSignType.RightDirection => "右方向",
            _ => ""
        };
    }

    private void HandleVoiceGuidance(int signValue, float distance, int index)
    {
        if (audioSource == null) return;
        NavSignType sign = (NavSignType)signValue;

        // 指示が変わったらリセット
        if (index != _lastVoiceInstructionIndex)
        {
            _lastVoiceInstructionIndex = index;
            _lastDistanceCall = -1;
        }

        // --- 4. 自動車でも確実になる音声トリガー (AudioBufferを使わない判定) ---

        // 500mフェーズに入った瞬間
        if (distance <= thresholds.Far && distance > thresholds.Middle && _lastDistanceCall != 500)
        {
            PlayGuidance(FarCallClip, signValue);
            _lastDistanceCall = 500;
        }
        // 300mフェーズに入った瞬間
        else if (distance <= thresholds.Middle && distance > thresholds.Near && _lastDistanceCall != 300)
        {
            PlayGuidance(MiddleCallClip, signValue);
            _lastDistanceCall = 300;
        }
        // 100mフェーズに入った瞬間
        else if (distance <= thresholds.Near && _lastDistanceCall != 100 && sign != NavSignType.None)
        {
            PlayGuidance(nearCallClip, signValue);
            _lastDistanceCall = 100;
        }
        // 50mフェーズに入った瞬間
        else if (distance <= thresholds.Nearby && _lastDistanceCall != 50 && sign != NavSignType.None)
        {
            if (sign == NavSignType.Destination) PlayGuidance(goalClip);
            else PlayGuidance(null, signValue);
            _lastDistanceCall = 50;
        }
    }

    private void PlayGuidance(AudioClip distanceClip, int sign = 0)
    {
        // 1. クールタイム（短時間の連続再生防止）
        if (Time.time - _lastPlayTime < PlayCooldown) return;
        _lastPlayTime = Time.time;

        // 2. すでに再生中の案内があれば止める
        if (_currentGuidanceCoroutine != null)
        {
            StopCoroutine(_currentGuidanceCoroutine);
        }

        _currentGuidanceCoroutine = StartCoroutine(PlayGuidanceRoutine(distanceClip, sign));
    }

    private IEnumerator PlayGuidanceRoutine(AudioClip distanceClip, int sign)
    {
        audioSource.Stop();
        // 1. ポーン（infoSE）
        if (infoSEClip != null)
        {
            audioSource.PlayOneShot(infoSEClip);
            yield return new WaitForSeconds(infoSEClip.length);
        }

        // 2. 「〇〇m先」
        if (distanceClip != null)
        {
            audioSource.PlayOneShot(distanceClip);
            yield return new WaitForSeconds(distanceClip.length);
        }

        // 3. 「右方向です」などの方向案内
        AudioClip directionClip = null;
        if (sign < 0) directionClip = leftTurnClip;
        else if (sign > 0 && sign != 4) directionClip = rightTurnClip;

        if (directionClip != null)
        {
            audioSource.PlayOneShot(directionClip);
        }

        _currentGuidanceCoroutine = null;
    }

    public void PlayFinishGuidance()
    {
        if (audioSource != null)
        {
            StartCoroutine(PlayFinishGuidanceRoutine());
        }
    }

    private IEnumerator PlayFinishGuidanceRoutine()
    {
        // 目的地接近の音声を再生
        if (goalClip != null)
        {
            audioSource.PlayOneShot(goalClip);

            // 音声が重ならないように、まず「再生したクリップの長さ」分待機
            yield return new WaitForSeconds(goalClip.length);
        }

        // --- ここで追加の1秒待機 ---
        yield return new WaitForSeconds(1.0f);

        // ねぎらいの音声を再生
        if (negiraiClip != null)
        {
            audioSource.PlayOneShot(negiraiClip);
        }
    }
}