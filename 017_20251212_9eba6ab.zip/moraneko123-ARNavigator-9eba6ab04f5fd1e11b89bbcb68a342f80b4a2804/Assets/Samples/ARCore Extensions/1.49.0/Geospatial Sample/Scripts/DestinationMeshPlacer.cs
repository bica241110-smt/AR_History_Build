using Google.XR.ARCoreExtensions;
using Google.XR.ARCoreExtensions.Samples.Geospatial;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class DestinationMeshPlacer : MonoBehaviour
{
    public GeospatialController GeospatialController;
    public GameObject DestinationPrefab;
    public GameObject CornerPrefab;

    [Tooltip("�n�ʂ���̍����I�t�Z�b�g (��: 0�Ȃ�n�ʁA0.2�Ȃ班������)")]
    public float AltitudeOffset = 0f;

    public float ScaleFactorPerMeter = 0.1f;
    public RouteLineRenderer routeLineRenderer;

    // ���폜: �萔�� GeoCalculator �̂��̂��g�p���邽�ߍ폜
    // const double EarthRadius = 6378137.0; 
    // const double Deg2Rad = Math.PI / 180.0;

    private double cameraAltitude;
    private double useAltitude;

    // --- ���I�����p�̐ݒ� ---
    [Header("Dynamic Route Settings")]
    public RouteProgressMonitor progressMonitor;
    public const int MAX_ACTIVE_ANCHORS = 20;

    private List<Vector2d> _fullRoutePath; // GeoCalculator��Vector2d���g�p
    private LinkedList<GameObject> _activeAnchors = new LinkedList<GameObject>();
    private int _nextSpawnIndex = 0;

    private ARGeospatialAnchor _lineBaseAnchor;
    private int _passedNodeCount = 0;

    [Header("Rotation / Smoothing")]
    public float RouteRotationOffset = 0f;
    [Range(0f, 0.99f)]
    public float RotationSmoothingAlpha = 0.15f;

    private float DeviceHeightOffset = 1.5f;

    private double _routeStartLat = double.NaN;
    private double _routeStartLon = double.NaN;
    private double _routeStartAlt = double.NaN;

    private void Awake()
    {
        // ... (�ȗ�: �ύX�Ȃ�) ...
        if (GeospatialController == null) DebugTextManager.Set("Destination", "GeospatialController ���ݒ�");
        if (DestinationPrefab == null) DebugTextManager.Set("Destination", "DestinationPrefab ���ݒ�");
    }

    public GameObject PlaceDestination(double latitude, double longitude, double altitude = double.NaN, double heading = 0.0, bool isCorner = false, Action<GameObject> onAsyncComplete = null)
    {
        // ... (�ȗ�: �ύX�Ȃ�) ...
        // PlaceDestination �͌��X double ���󂯎��̂ŕύX�s�v
        if (GeospatialController == null || GeospatialController.EarthManager == null || GeospatialController.AnchorManager == null) return null;

        var earthManager = GeospatialController.EarthManager;
        cameraAltitude = earthManager.CameraGeospatialPose.Altitude;
        useAltitude = double.IsNaN(altitude) ? cameraAltitude : altitude;
        double targetAltitude = useAltitude + AltitudeOffset - DeviceHeightOffset;
        Quaternion rot = Quaternion.AngleAxis((float)heading, Vector3.up);

        var anchor = GeospatialController.AnchorManager.AddAnchor(latitude, longitude, targetAltitude, rot);

        if (anchor != null)
        {
            InstantiateUnderAnchor(anchor.gameObject, isCorner);
            onAsyncComplete?.Invoke(anchor.gameObject);
            return anchor.gameObject;
        }
        else
        {
            StartCoroutine(ResolveOnTerrainRoutine(latitude, longitude, rot, isCorner, onAsyncComplete));
            return null;
        }
    }

    // ... (InstantiateUnderAnchor, ResolveOnTerrainRoutine, GetScaleForDistance �͕ύX�Ȃ�) ...
    private void InstantiateUnderAnchor(GameObject anchorGO, bool isCorner = false)
    {
        if (DestinationPrefab == null || anchorGO == null) return;
        var prefab = (isCorner && CornerPrefab != null) ? CornerPrefab : DestinationPrefab;
        var go = Instantiate(prefab, anchorGO.transform);
        go.transform.SetParent(anchorGO.transform, false);
        go.transform.localPosition = Vector3.zero;
        go.transform.localRotation = Quaternion.identity;
        Vector3 camPos = Camera.main ? Camera.main.transform.position : Vector3.zero;
        float scale = GetScaleForDistance(anchorGO.transform.position, camPos);
        go.transform.localScale = Vector3.one * scale;
        if (!go.activeInHierarchy) go.SetActive(true);
        var rend = go.GetComponentInChildren<Renderer>();
        if (rend != null && !rend.enabled) rend.enabled = true;
    }

    private IEnumerator ResolveOnTerrainRoutine(double lat, double lon, Quaternion rot, bool isCorner, Action<GameObject> onComplete)
    {
        var promise = GeospatialController.AnchorManager.ResolveAnchorOnTerrainAsync(lat, lon, AltitudeOffset, rot);
        yield return promise;
        var result = promise.Result;
        if (result.TerrainAnchorState == TerrainAnchorState.Success && result.Anchor != null)
        {
            InstantiateUnderAnchor(result.Anchor.gameObject, isCorner);
            onComplete?.Invoke(result.Anchor.gameObject);
        }
        else
        {
            onComplete?.Invoke(null);
        }
    }

    private float GetScaleForDistance(Vector3 anchorPos, Vector3 camPos)
    {
        float dist = Vector3.Distance(anchorPos, camPos);
        return Mathf.Clamp(dist * ScaleFactorPerMeter, 0.1f, 10f);
    }

    // =====================================================================
    // ���[�g�J�n�E�Ǘ�
    // =====================================================================

    // ���C�� 2: ������ List<Vector2d> �ɕύX
    public void StartDynamicRoute(List<Vector2d> routePoints)
    {
        if (routePoints == null || routePoints.Count == 0) return;
        if (progressMonitor == null) return;

        ClearCurrentRoute();

        _fullRoutePath = routePoints;
        _nextSpawnIndex = 0;
        _passedNodeCount = 0;

        progressMonitor.OnTargetReached -= OnNextAnchorReached;
        progressMonitor.OnTargetReached += OnNextAnchorReached;

        int initialCount = Mathf.Min(MAX_ACTIVE_ANCHORS, _fullRoutePath.Count);
        for (int i = 0; i < initialCount; i++)
        {
            SpawnNextAnchor();
        }

        UpdateMonitorTarget();

        // �n�_�̐ݒ�i���ݒ�Ȃ烋�[�g�̍ŏ��̓_���g�p�j
        if (double.IsNaN(_routeStartLat) || double.IsNaN(_routeStartLon))
        {
            // Vector2d �Ȃ̂� p0.y, p0.x �� double �ł�
            Vector2d p0 = routePoints[0];
            SetRouteStartCoordinate(p0.y, p0.x, double.NaN);
        }

        StartCoroutine(DrawRouteLineFromPositions(_fullRoutePath, _routeStartLat, _routeStartLon, _routeStartAlt, 1, double.NaN));
    }

    private void OnNextAnchorReached(int passedIndex, bool isGoal)
    {
        if (isGoal)
        {
            DebugTextManager.Set("Destination", "�ړI�n�ɓ������܂����I");
            progressMonitor.StopMonitoring();
            return;
        }

        if (_activeAnchors.Count > 0)
        {
            GameObject passedAnchor = _activeAnchors.First.Value;
            _activeAnchors.RemoveFirst();
            if (passedAnchor != null) Destroy(passedAnchor);
        }

        _passedNodeCount++;
        SpawnNextAnchor();
        UpdateMonitorTarget();
    }

    private void SpawnNextAnchor()
    {
        if (_fullRoutePath == null || _nextSpawnIndex >= _fullRoutePath.Count) return;

        // ���C�� 3: ���o���ϐ��� Vector2d ��
        Vector2d p = _fullRoutePath[_nextSpawnIndex];

        // p.y (lat), p.x (lon) �� double �Ȃ̂ł��̂܂ܓn����
        GameObject newAnchor = PlaceDestination(p.y, p.x, double.NaN, 0.0, false, (asyncAnchor) =>
        {
            if (asyncAnchor != null)
            {
                _activeAnchors.AddLast(asyncAnchor);
                if (_activeAnchors.Count == 1) UpdateMonitorTarget();
            }
        });

        if (newAnchor != null)
        {
            _activeAnchors.AddLast(newAnchor);
        }

        _nextSpawnIndex++;
    }

    private void UpdateMonitorTarget()
    {
        if (_activeAnchors.Count > 0 && _activeAnchors.First.Value != null)
        {
            int targetIndex = _passedNodeCount;
            bool isLast = (targetIndex >= _fullRoutePath.Count - 1);
            progressMonitor.SetTarget(_activeAnchors.First.Value.transform, targetIndex, isLast);
        }
        else
        {
            progressMonitor.StopMonitoring();
        }
    }

    // ... (ClearCurrentRoute, ClearActiveAnchors, SetRouteStartCoordinate �͕ύX�Ȃ�) ...
    public void ClearCurrentRoute()
    {
        if (routeLineRenderer != null)
        {
            routeLineRenderer.transform.SetParent(null);
            routeLineRenderer.gameObject.SetActive(false);
            var lr = routeLineRenderer.GetComponent<LineRenderer>();
            if (lr != null) { lr.positionCount = 0; lr.enabled = false; }
        }
        if (_lineBaseAnchor != null) { Destroy(_lineBaseAnchor.gameObject); _lineBaseAnchor = null; }
        ClearActiveAnchors();
        DebugTextManager.Log("Route", "���[�g�������Z�b�g�����B");
    }

    public void ClearActiveAnchors()
    {
        foreach (var anchor in _activeAnchors) { if (anchor != null) Destroy(anchor); }
        _activeAnchors.Clear();
        if (progressMonitor != null) progressMonitor.StopMonitoring();
    }

    public void SetRouteStartCoordinate(double lat, double lon, double alt = double.NaN)
    {
        _routeStartLat = lat;
        _routeStartLon = lon;
        _routeStartAlt = alt;
    }

    // =====================================================================
    // DrawRouteLineFromPositions (�C����: ��]�␳�폜 & ��������)
    // =====================================================================
    private IEnumerator DrawRouteLineFromPositions(List<Vector2d> routePoints, double baseLat, double baseLon, double baseAlt, int step, double altitude)
    {
        if (routePoints == null || routePoints.Count < 2) yield break;
        if (GeospatialController == null || GeospatialController.AnchorManager == null) yield break;
        if (routeLineRenderer == null) yield break;

        // ��_�iOrigin�j�̊m��
        double originLat = double.IsNaN(_routeStartLat) ? baseLat : _routeStartLat;
        double originLon = double.IsNaN(_routeStartLon) ? baseLon : _routeStartLon;
        double originAlt = double.IsNaN(_routeStartAlt) ? baseAlt : _routeStartAlt;

        // 1. ��A���J�[�𐶐�
        // Quaternion.identity �Ő�������ƁA�����I�ɁyZ+=�k, X+=��, Y+=��z�ɂȂ�܂�
        var baseAnchor = GeospatialController.AnchorManager.AddAnchor(originLat, originLon, originAlt, Quaternion.identity);

        if (baseAnchor == null)
        {
            // �t�H�[���o�b�N: TerrainAnchor
            var terrainPromise = GeospatialController.AnchorManager.ResolveAnchorOnTerrainAsync(originLat, originLon, 0, Quaternion.identity);
            yield return terrainPromise;
            var tResult = terrainPromise.Result;
            if (tResult.TerrainAnchorState == TerrainAnchorState.Success && tResult.Anchor != null)
            {
                baseAnchor = tResult.Anchor;
            }
            else
            {
                DebugTextManager.Log("Destination", "��A���J�[�������s: LineRenderer���~");
                yield break;
            }
        }

        yield return new WaitForEndOfFrame();

        _lineBaseAnchor = baseAnchor;

        // RouteLineRenderer���A���J�[�̎q�ɂ���
        routeLineRenderer.transform.SetParent(_lineBaseAnchor.transform, false);
        routeLineRenderer.transform.localPosition = Vector3.zero;

        // ���d�v�C��: ��]�����Z�b�g�iIdentity = �k�����j�ɂ���
        // GeospatialAnchor�̎q�ł���΁AZ���������I�ɖk���������߁AEunRotation�ɂ��␳�͕s�v�i�ނ���L�Q�j�ł��B
        routeLineRenderer.transform.localRotation = Quaternion.identity;

        DebugTextManager.Log("Destination", $"LineRenderer��A���J�[�ݒu���� (Rot=Identity)");

        // -------------------- ���W�v�Z�iENU & double���x�j --------------------
        List<Vector3> localPositions = new List<Vector3>(routePoints.Count);

        // ��������: �A���J�[(�J�����ʒu)����ǂꂭ�炢�����邩
        // DeviceHeightOffset (��1.5m) ��������ƒn�ʕt�߂ɂȂ�܂�
        // �������n�ʂ�蕂���������Ȃ� AltitudeOffset ��傫�����Ă�������
        float yOffset = AltitudeOffset - DeviceHeightOffset;

        for (int i = 0; i < routePoints.Count; i += step)
        {
            double pLat = routePoints[i].y;
            double pLon = routePoints[i].x;

            // ��_����̑��΃��[�g�����W (East, North) ���v�Z
            // ������ GeoToENU �͓����� EarthRadius * ... �̌v�Z�����Ă��郁�\�b�h
            Vector2d enu = GeoCalculator.GeoToENU(pLon, pLat, originLon, originLat);

            // Unity���W�n (�e��GeospatialAnchor�Ȃ̂ŁA���̂܂ܓK�p)
            // East  -> X
            // North -> Z
            float x = (float)enu.x;
            float z = (float)enu.y;

            // Y���̓A���J�[����̑��΍���
            localPositions.Add(new Vector3(x, yOffset, z));
        }

        // �Ō�̓_��ǉ��istep�Ŕ�΂��ꂽ�ꍇ�j
        if ((routePoints.Count - 1) % step != 0)
        {
            Vector2d lastP = routePoints[routePoints.Count - 1];
            Vector2d enu = GeoCalculator.GeoToENU(lastP.x, lastP.y, originLon, originLat);
            localPositions.Add(new Vector3((float)enu.x, yOffset, (float)enu.y));
        }

        if (localPositions.Count > 1)
        {
            // RouteLineRenderer�N���X���� useWorldSpace = false �ɂȂ��Ă��邱�Ƃ�O��Ƃ���
            // DrawRouteLocal �� useWorldSpace=false �ŕ`�悷�郁�\�b�h
            if (!routeLineRenderer.gameObject.activeInHierarchy)
            {
                routeLineRenderer.gameObject.SetActive(true);
            }

            routeLineRenderer.DrawRouteLocal(localPositions);
            DebugTextManager.Log("Destination", $"���[�g���C���`��: {localPositions.Count}�_");
        }
    }
}