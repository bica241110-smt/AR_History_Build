using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(LineRenderer))]
public class RouteLineRenderer : MonoBehaviour
{
    private LineRenderer lineRenderer;

    private static readonly Color RouteColor = new Color(0f, 1f, 1f, 0.55f);

    void Awake()
    {
        InitializeLineRenderer();
    }

    private void InitializeLineRenderer()
    {
        lineRenderer = GetComponent<LineRenderer>();

        if (lineRenderer == null)
        {
            lineRenderer = gameObject.AddComponent<LineRenderer>();
            DebugTextManager.Log("LineRenderer", "LineRenderer �����݂����A�V�K�ǉ����܂����B");
        }

        // �������ݒ�
        lineRenderer.enabled = true;
        lineRenderer.positionCount = 0;
        lineRenderer.useWorldSpace = true;

        // Material
        if (lineRenderer.material == null)
        {
            lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        }

        // �F�ݒ�
        lineRenderer.startColor = RouteColor;
        lineRenderer.endColor = RouteColor;
        lineRenderer.material.color = RouteColor;

        DebugTextManager.Set("LineRenderer", "RouteLineRenderer initialized.");
    }

    /// <summary>
    /// �o�H�����[�J�����W�ŕ`��
    /// </summary>
    public void DrawRouteLocal(List<Vector3> localPositions)
    {
        DrawInternal(localPositions, useWorldSpace: false);
    }

    /// <summary>
    /// �o�H�����[���h���W�ŕ`��
    /// </summary>
    public void DrawRoute(List<Vector3> worldPositions)
    {
        DrawInternal(worldPositions, useWorldSpace: true);
    }

    /// <summary>
    /// ���ʕ`�揈��
    /// </summary>
    private void DrawInternal(List<Vector3> positions, bool useWorldSpace)
    {
        if (!ValidateLineRenderer()) return;

        if (positions == null || positions.Count < 2)
        {
            lineRenderer.positionCount = 0;
            DebugTextManager.Log("LineRenderer", "�`��L�����Z��: �_���s�����Ă��܂��B");
            return;
        }

        lineRenderer.useWorldSpace = useWorldSpace;
        lineRenderer.positionCount = positions.Count;

        // �����]���i���ʂ� ToArray() �������j
        for (int i = 0; i < positions.Count; i++)
        {
            lineRenderer.SetPosition(i, positions[i]);
        }

        lineRenderer.enabled = true;
        DebugTextManager.Log("LineRenderer", $"�`�抮��: {positions.Count} �_ / {(useWorldSpace ? "World" : "Local")}");
    }

    private bool ValidateLineRenderer()
    {
        if (lineRenderer == null)
        {
            InitializeLineRenderer();
        }
        return lineRenderer != null;
    }
}
