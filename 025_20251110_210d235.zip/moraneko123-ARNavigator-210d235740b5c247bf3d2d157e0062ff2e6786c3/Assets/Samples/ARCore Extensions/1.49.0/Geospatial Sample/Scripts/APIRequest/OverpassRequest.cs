using SimpleJSON;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using Google.XR.ARCoreExtensions.Samples.Geospatial;

public class OverpassRequest : MonoBehaviour
{
    public static OverpassRequest Instance { get; private set; }
    public static OSRMRouteRequest RouteRequest { get; private set; }

    public static MapTileUI MapTileUI { get; private set; }

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        // Try to initialize RouteRequest from the same GameObject or find one in the scene
        if (RouteRequest == null)
        {
            RouteRequest = GetComponent<OSRMRouteRequest>();
            if (RouteRequest == null)
                RouteRequest = UnityEngine.Object.FindFirstObjectByType<OSRMRouteRequest>();
        }
    }

    /// <summary>
    /// ���݈ʒu����Ŋ��̃o�X����������ċ�����\��
    /// </summary>
    public IEnumerator FetchBusStopInfoCoroutine(double latitude, double longitude)
    {
        string query = $@"
        [out:json];
        node(around:2000,{latitude},{longitude})[highway=bus_stop];
        out body;";

        var form = new WWWForm();
        form.AddField("data", query);

        // Log the request payload to TargetRenderer (API�����̂�)
        if (TargetRenderer.Instance != null)
        {
            TargetRenderer.Instance.AppendApiLog($"Overpass request payload:\n{query}");
        }

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();

            // Always log response code and body for API troubleshooting
            long responseCode = www.responseCode;
            string responseBody = www.downloadHandler != null ? www.downloadHandler.text : string.Empty;

            if (www.result != UnityWebRequest.Result.Success)
            {
                string err = "API�G���[: " + www.error;
                Debug.LogError(err);

                if (TargetRenderer.Instance != null)
                {
                    string full = $"Overpass ERROR\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nError: {www.error}\nBody:\n{responseBody}";
                    TargetRenderer.Instance.AppendApiLog(full);
                    TargetRenderer.Instance.Display(err);
                }
                else
                {
                    // fall back to Display if exists
                    if (TargetRenderer.Instance != null)
                        TargetRenderer.Instance.Display(err);
                }

                yield break;
            }

            string json = responseBody;
#if UNITY_EDITOR
            Debug.Log("�擾�����o�X��f�[�^: " + json);
#endif

            // Also append successful response body to TargetRenderer for API diagnostics
            if (TargetRenderer.Instance != null)
            {
                string full = $"Overpass RESPONSE\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nBody:\n{json}";
                TargetRenderer.Instance.AppendApiLog(full);
            }

            // JSON���
            var parsed = JSON.Parse(json);
            var elements = parsed["elements"];

            if (elements == null || elements.Count == 0)
            {
                string msg = "�߂��Ƀo�X�₪������܂���B";
                if (TargetRenderer.Instance != null)
                    TargetRenderer.Instance.Display(msg);
                yield break;
            }

            // �Ŋ��̃o�X���T���i�����̓��Ŕ�r���� sqrt �������j
            double nearestDistSq = double.MaxValue;
            double nearestDist = 0.0;
            string nearestName = "���O�Ȃ�";
            double nearestLat = 0, nearestLon = 0;

            for (int i = 0; i < elements.Count; i++)
            {
                var node = elements[i];
                double lat = node["lat"];
                double lon = node["lon"];
                string name = "���O�Ȃ�";
                if (node["tags"] != null && node["tags"]["name"] != null)
                    name = node["tags"]["name"];

                double distSq = GeoCalculator.GetDistanceSquared(latitude, longitude, lat, lon);
                if (distSq < nearestDistSq)
                {
                    nearestDistSq = distSq;
                    nearestName = name;
                    nearestLat = lat;
                    nearestLon = lon;
                }
            }

            // ���ۂ̋����͍Ō�Ɉ�x�����v�Z
            nearestDist = GeoCalculator.GetDistance(latitude, longitude, nearestLat, nearestLon);

            double nearestDire = GeoCalculator.GetDirection(latitude, longitude, nearestLat, nearestLon);

            if (RouteRequest != null)
            {
                // OSRM GetRoute signature: GetRoute(startLon, startLat, endLon, endLat)
                yield return StartCoroutine(RouteRequest.GetRoute(longitude, latitude, nearestLon, nearestLat,
                    (routePoints) =>
                    {
                        // routePoints �Ɉܓx�o�x���X�g�������Ă���
                        // ������ AR �I�u�W�F�N�g�� LineRenderer �ɓn��
                    }));
            }
            else
            {
                Debug.LogWarning("RouteRequester �����������ł��B");
            }

            // GeospatialController �ɓn���� AR �\�������݂�i����΁j
            var geoCtrl = UnityEngine.Object.FindFirstObjectByType<Google.XR.ARCoreExtensions.Samples.Geospatial.GeospatialController>();
            if (geoCtrl != null)
            {
                // ���x�͕s���Ȃ̂� NaN ��n���iDestinationMeshPlacer ���ŃJ�������x���g���܂��j
                geoCtrl.PlaceDestinationFromLatLon(longitude, latitude, double.NaN, nearestDire);
            }

            // ���ʂ� TargetRenderer �ɕ\��
            if (TargetRenderer.Instance != null)
            {
                TargetRenderer.Instance.DisplayBusStop(nearestName, nearestDist, nearestDire, nearestLat, nearestLon);

                if (RouteRequest != null)
                {
                    // �������𓝈ꂵ�ČĂяo��

                    yield return StartCoroutine(RouteRequest.GetRoute(longitude, latitude, nearestLon, nearestLat));
                }

                yield return StartCoroutine(MapTileUI.LoadMapTile(longitude,latitude));
            }
            else
            {
                string result = $"�Ŋ��̃o�X��: {nearestName}\n" +
                                $"����: {nearestDist:F1} m\n" +
                                $"����: {nearestDire:F1}��\n" +
                                $"���W: ({nearestLat}, {nearestLon})";
                Debug.Log(result);
            }
        }
    }
}