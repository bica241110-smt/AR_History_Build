using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARSubsystems;
using Google.XR.ARCoreExtensions;
using Google.XR.ARCoreExtensions.Samples.Geospatial;

public class DestinationMeshPlacer : MonoBehaviour
{
    public GeospatialController GeospatialController;
    public GameObject DestinationPrefab;
    public GameObject CornerPrefab;
    public float AltitudeOffset = 0f;
    public float ScaleFactorPerMeter = 0.1f;
    public RouteLineRenderer routeLineRenderer;

    // --- ���W�ϊ��p: �n����ł̋������Z�W���i�����悻�j ---
    const double EarthRadius = 6378137.0; // m�iWGS84�j

    private double cameraAltitude;
    private double useAltitude;
    // �ܓx�o�x�����ƂɖړI�n��z�u
    public void PlaceDestination(double latitude, double longitude, double altitude = double.NaN, double heading = 0.0)
    {
        if (GeospatialController == null)
        {
            Debug.LogError("DestinationMeshPlacer: GeospatialController �����ݒ�ł��B");
            return;
        }

        if (GeospatialController.EarthManager == null || GeospatialController.AnchorManager == null)
        {
            Debug.LogError("DestinationMeshPlacer: EarthManager �܂��� AnchorManager �����ݒ�ł��B");
            return;
        }

        if (DestinationPrefab == null)
        {
            Debug.LogError("DestinationMeshPlacer: DestinationPrefab �����ݒ�ł��B");
            return;
        }

        if (GeospatialController.EarthManager.EarthState != EarthState.Enabled ||
            GeospatialController.EarthManager.EarthTrackingState != TrackingState.Tracking)
        {
            Debug.LogWarning("Geospatial ���܂����[�J���C�Y����Ă��܂���BTracking �ɂȂ�̂�҂��Ă��������B");
            return;
        }
        //
        cameraAltitude = GeospatialController.EarthManager.CameraGeospatialPose.Altitude;
        useAltitude = double.IsNaN(altitude) ? cameraAltitude : altitude;
        if (double.IsNaN(useAltitude) || double.IsInfinity(useAltitude))
        {
            useAltitude = 0.0;
            Debug.LogWarning("DestinationMeshPlacer: �L���ȍ��x���擾�ł��Ȃ��������߁A0m ���g�p���܂��B");
        }

        Quaternion rot = Quaternion.AngleAxis((float)heading, Vector3.up);

        var anchor = GeospatialController.AnchorManager.AddAnchor(latitude, longitude, useAltitude + AltitudeOffset, rot);

        if (anchor != null)
        {
            InstantiateUnderAnchor(anchor.gameObject);
        }
        else
        {
            StartCoroutine(ResolveOnTerrainRoutine(latitude, longitude, rot));
        }
    }

    private void InstantiateUnderAnchor(GameObject anchorGO)
    {
        if (DestinationPrefab == null || anchorGO == null)
        {
            return;
        }

        var go = Instantiate(DestinationPrefab, anchorGO.transform);
        go.transform.localPosition = Vector3.zero;
        go.transform.localRotation = Quaternion.identity;

        Vector3 camPos = Camera.main ? Camera.main.transform.position : Vector3.zero;
        go.transform.localScale = Vector3.one * GetScaleForDistance(anchorGO.transform.position, camPos);
    }

    private IEnumerator ResolveOnTerrainRoutine(double lat, double lon, Quaternion rot)
    {
        var promise = GeospatialController.AnchorManager.ResolveAnchorOnTerrainAsync(lat, lon, 0, rot);
        yield return promise;

        var result = promise.Result;
        if (result.TerrainAnchorState == TerrainAnchorState.Success && result.Anchor != null)
        {
            InstantiateUnderAnchor(result.Anchor.gameObject);
        }
        else
        {
            Debug.LogError($"ResolveOnTerrain failed: {result.TerrainAnchorState}");
        }
    }

    private float GetScaleForDistance(Vector3 anchorPos, Vector3 camPos)
    {
        float dist = Vector3.Distance(anchorPos, camPos);
        float s = Mathf.Clamp(dist * ScaleFactorPerMeter, 0.1f, 10f);
        return s;
    }

    // --- OSRM�o�H�_���烁�b�V�������[�g���C����z�u ---
    public void PlaceRouteFromOSRM(List<Vector2> routePoints, int step = 10, double altitude = double.NaN, double heading = 0.0)
    {
        if (routePoints == null || routePoints.Count == 0)
        {
            Debug.LogWarning("PlaceRouteFromOSRM: routePoints ����ł��B");
            return;
        }

        if (step <= 0) step = 1;
        StartCoroutine(PlaceRouteRoutine(routePoints, step, altitude, heading));
    }

    private IEnumerator PlaceRouteRoutine(List<Vector2> routePoints, int step, double altitude, double heading)
    {
        List<Vector3> worldPositions = new List<Vector3>();
        var earthManager = GeospatialController.EarthManager;
        var camPose = earthManager.CameraGeospatialPose;

        double baseLat = camPose.Latitude;
        double baseLon = camPose.Longitude;
        double baseAlt = camPose.Altitude;

        for (int i = 0; i < routePoints.Count; i += step)
        {
            Vector2 p = routePoints[i];
            double lon = p.x;
            double lat = p.y;

            // --- �A���J�[�z�u ---
            PlaceDestination(lat, lon, altitude, heading);

            // --- �ܓx�o�x �� Unity��ԑ��Έʒu�ɕϊ� ---
            Vector3 unityPos = GeoToUnityOffset(lat, lon, altitude, baseLat, baseLon, baseAlt);
            worldPositions.Add(unityPos);

            if ((i / step) % 10 == 0)
                yield return null;
        }

        // --- ���`�� ---
        if (routeLineRenderer != null && worldPositions.Count > 1)
        {
            routeLineRenderer.DrawRoute(worldPositions);
            Debug.Log($"���[�g���C����`�悵�܂����B�_��: {worldPositions.Count}");
        }
        else
        {
            Debug.LogWarning("RouteLineRenderer �����ݒ�A�܂��͓_���s�����Ă��܂��B");
        }
    }

    /// <summary>
    /// �ܓx�o�x����Unity��Ԃ̑��΍��W�ɕϊ�����
    /// </summary>
    private Vector3 GeoToUnityOffset(double lat, double lon, double alt, double baseLat, double baseLon, double baseAlt)
    {
        // �ܓx�E�o�x�̍������[�g�����Z
        double latRad = Mathf.Deg2Rad * (float)baseLat;
        double dLat = (lat - baseLat) * Mathf.Deg2Rad;
        double dLon = (lon - baseLon) * Mathf.Deg2Rad;

        double x = EarthRadius * dLon * Mathf.Cos((float)latRad); // ��������
        double z = EarthRadius * dLat;                            // ��k����
        double y = useAltitude;              // ���፷

        // Unity���W�n�ɍ��킹��iZ�O���AX�E�����j
        return new Vector3((float)x, (float)y, (float)z);
    }
}
