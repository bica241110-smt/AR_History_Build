using UnityEngine;
using System;

/// <summary>
/// 現在地とターゲットアンカーとの距離を監視し、
/// 通過（接近）を検知してイベントを発行するクラス
/// </summary>
public class RouteProgressMonitor : MonoBehaviour
{
    // 検知距離（インスペクタで設定可能）
    [SerializeField] private float arrivalThreshold = 10f;

    // 通過時に呼ばれるイベント
    public event Action<int, bool> OnTargetReached;

    // 現在監視中のターゲット
    private Transform _currentTarget;
    public Transform CurrentTarget => _currentTarget;

    private int _currentTargetIndex;      // 現在監視中のノード番号
    private bool _isFinalDestination;     // これが最後の目的地か？
    private Camera _mainCamera;

    // ★追加: 直前に通過したノードのインデックスを記録する変数
    private int _lastPassedIndex = -1;

    // ★追加: 目的地名
    public string DestinationName { get; set; } = "ARGeospatialAnchor";

    private void Start()
    {
        _mainCamera = Camera.main;
    }

    /// <summary>
    /// 新しい監視対象を設定する
    /// </summary>
    public void SetTarget(Transform target, int index, bool isLast)
    {
        // ★追加: ルートがリセットされた（0番目に戻った）場合、履歴をクリアする
        if (index == 0)
        {
            _lastPassedIndex = -1;
        }

        _currentTarget = target;
        _currentTargetIndex = index;
        _isFinalDestination = isLast;
    }

    /// <summary>
    /// 監視を停止する
    /// </summary>
    public void StopMonitoring()
    {
        _currentTarget = null;
        _lastPassedIndex = -1; // 停止時もリセット
    }

    private void Update()
    {
        if (_currentTarget == null || _mainCamera == null) return;

        // ★改善提案: 高さ(Y)の誤差を無視して「水平距離」だけで判定したほうがARでは安定します
        // Vector3.Distance だと、スマホを高く掲げたり、地面設定がずれていると検知しにくい場合があります
        Vector3 playerPos = _mainCamera.transform.position;
        Vector3 targetPos = _currentTarget.position;

        // 平面距離 (XZ) のみを計算
        float distanceXZ = Vector2.Distance(
            new Vector2(playerPos.x, playerPos.z),
            new Vector2(targetPos.x, targetPos.z)
        );

        // ※元の3D距離を使いたい場合はここを distanceXZ ではなく元の distance に戻してください
        if (distanceXZ < arrivalThreshold)
        {
            // ★重要: 同じインデックスで二重発火しないようにガード
            if (_currentTargetIndex == _lastPassedIndex)
            {
                _currentTarget = null; // 監視だけ外して帰る
                return;
            }

            // 通過したことを記録
            _lastPassedIndex = _currentTargetIndex;

            // ログ出力
            string type = _isFinalDestination ? "【GOAL】" : "【Point】";
            DebugTextManager.Log("ProgressMonitor", $"{type} ノード{_currentTargetIndex}を通過。距離:{distanceXZ:F2}m");

            // 一旦ターゲットを外す
            _currentTarget = null;

            // リスナーに通知
            OnTargetReached?.Invoke(_currentTargetIndex, _isFinalDestination);
        }
    }
}