using Google.XR.ARCoreExtensions;
using Google.XR.ARCoreExtensions.Samples.Geospatial;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class DestinationMeshPlacer : MonoBehaviour
{
    public GeospatialController GeospatialController;
    public GameObject DestinationPrefab;
    public GameObject CornerPrefab;

    public float AltitudeOffset = 0f;
    public RouteLineRenderer routeLineRenderer;

    [Header("Dynamic Route Settings")]
    public RouteProgressMonitor progressMonitor;
    public const int MAX_ACTIVE_ANCHORS = 20;

    private List<Vector2d> _fullRoutePath;
    private LinkedList<GameObject> _activeAnchors = new LinkedList<GameObject>();
    private int _nextSpawnIndex = 0;
    private int _passedNodeCount = 0;

    private float DeviceHeightOffset = 1.5f;
    private double _routeStartLat = double.NaN;
    private double _routeStartLon = double.NaN;

    // 基準アンカーを保持（頻繁な親の切り替えを防ぐ）
    private GameObject _persistentRootAnchor = null;

    public void StartDynamicRoute(List<Vector2d> routePoints, string destinationName = "ARGeospatialAnchor")
    {
        if (routePoints == null || routePoints.Count == 0) return;

        // 【デバッグログ】入力データのチェック
        if (routePoints.Count >= 2)
        {
            DebugTextManager.Log("DataCheck", $"P0:{routePoints[0].y:F6}/{routePoints[0].x:F6}, P1:{routePoints[1].y:F6}/{routePoints[1].x:F6}");
            if (routePoints[0].x == routePoints[1].x && routePoints[0].y == routePoints[1].y)
            {
                DebugTextManager.Log("DataCheck", "<color=red>警告: ルートの座標が重複しています！</color>");
            }
        }

        ClearCurrentRoute();
        _fullRoutePath = routePoints;
        // 追加: 目的地名をモニターにセット
        if (progressMonitor != null) progressMonitor.DestinationName = destinationName;

        progressMonitor.OnTargetReached -= OnNextAnchorReached;
        progressMonitor.OnTargetReached += OnNextAnchorReached;

        int initialCount = Mathf.Min(MAX_ACTIVE_ANCHORS, _fullRoutePath.Count);
        for (int i = 0; i < initialCount; i++) { SpawnNextAnchor(); }

        UpdateMonitorTarget();
        UpdateRouteLineFromAnchors();
    }

    private void OnNextAnchorReached(int passedIndex, bool isGoal)
    {
        if (isGoal) { progressMonitor.StopMonitoring(); return; }

        if (_activeAnchors.Count > 0)
        {
            GameObject passedAnchor = _activeAnchors.First.Value;
            _activeAnchors.RemoveFirst();
            if (passedAnchor == _persistentRootAnchor) _persistentRootAnchor = null; // Rootが消える場合はリセット
            if (passedAnchor != null) Destroy(passedAnchor);
        }

        _passedNodeCount++;
        SpawnNextAnchor();
        UpdateMonitorTarget();
        UpdateRouteLineFromAnchors();
    }

    private void SpawnNextAnchor()
    {
        if (_fullRoutePath == null || _nextSpawnIndex >= _fullRoutePath.Count) return;

        Vector2d p = _fullRoutePath[_nextSpawnIndex];
        double heading = (_nextSpawnIndex > 0) ? GeoCalculator.GetDirection(_fullRoutePath[_nextSpawnIndex - 1].y, _fullRoutePath[_nextSpawnIndex - 1].x, p.y, p.x) : 0.0;

        GameObject newAnchor = PlaceDestination(p.y, p.x, double.NaN, heading, false, (asyncAnchor) =>
        {
            if (asyncAnchor != null && !_activeAnchors.Contains(asyncAnchor))
            {
                _activeAnchors.AddLast(asyncAnchor);
                UpdateRouteLineFromAnchors();
            }
        });

        if (newAnchor != null && !_activeAnchors.Contains(newAnchor))
        {
            _activeAnchors.AddLast(newAnchor);
            UpdateRouteLineFromAnchors();
        }
        _nextSpawnIndex++;
    }

    public void UpdateRouteLineFromAnchors()
    {
        if (routeLineRenderer == null || _activeAnchors.Count < 2) return;

        var earth = GeospatialController.EarthManager;
        if (earth.EarthTrackingState != TrackingState.Tracking) return;

        // 1. 確定済みアンカーの抽出とワールド座標ログ
        List<GameObject> confirmed = new List<GameObject>();
        foreach (var a in _activeAnchors)
        {
            if (a == null) continue;
            
            // 1. まずトラッキング状態をチェック（これは今のまま）
            var geoAnchor = a.GetComponent<ARGeospatialAnchor>();
            var trackingState = (geoAnchor != null) ? geoAnchor.trackingState : 
                                a.GetComponent<ARAnchor>()?.trackingState ?? TrackingState.None;

            if (trackingState != TrackingState.Tracking) continue;

            // 2. 【追加】位置が初期座標 (0, 1.12, 0) 付近で止まっていないかチェック
            // 完全に 0 ではなく、わずかな誤差を考慮します
            Vector3 pos = a.transform.position;
            bool isAtOrigin = Mathf.Abs(pos.x) < 0.01f && Mathf.Abs(pos.z) < 0.01f;

            if (isAtOrigin) 
            {
                // まだ原点にいる場合は、トラッキング中であっても「解決中」とみなしてスキップ
                continue; 
            }

            confirmed.Add(a);
        }

        if (confirmed.Count < 2)
        {
            DebugTextManager.Log("Line", "確定アンカー待ち...");
            return;
        }

        // 2. 基準アンカー（Root）の決定：基本は最初の確定アンカーで固定
        if (_persistentRootAnchor == null || !_persistentRootAnchor.activeInHierarchy)
        {
            _persistentRootAnchor = confirmed[0];
        }

        // LineRendererの親子付け
        if (routeLineRenderer.transform.parent != _persistentRootAnchor.transform)
        {
            routeLineRenderer.transform.SetParent(_persistentRootAnchor.transform, false);
            routeLineRenderer.transform.localPosition = Vector3.zero;
        }

        // 3. ローカル座標への変換と「全点一致」チェック
        List<Vector3> locals = new List<Vector3>();
        bool allSame = true;
        Vector3 firstPos = Vector3.zero;

        for (int i = 0; i < confirmed.Count; i++)
        {
            Vector3 worldPos = confirmed[i].transform.position;
            Vector3 lp = _persistentRootAnchor.transform.InverseTransformPoint(worldPos);
            locals.Add(lp);

            if (i < 3)
            { // 先頭3つだけ表示（ログの埋め尽くし防止）
                DebugTextManager.Log($"localPos", $"Check_{i} | W_Pos:{worldPos.ToString("F3")} | L_Pos:{lp.ToString("F3")}");
            }

            if (i == 0) firstPos = lp;
            else if (Vector3.Distance(lp, firstPos) > 0.01f) allSame = false;
        }

        // 4. 異常検知：全ての点が重なっている場合は描画しない
        if (allSame)
        {
            DebugTextManager.Log("Line", "<color=yellow>警告: 全アンカーが同一点に重なっています</color>");
            // ワールド座標も確認
            DebugTextManager.Log("WorldCheck", $"W0:{confirmed[0].transform.position}");
            return;
        }

        // 5. 描画
        routeLineRenderer.gameObject.SetActive(true);
        routeLineRenderer.DrawRouteLocal(locals);

        DebugTextManager.Log("Line", $"描画成功: {locals.Count}点 / Root:{_persistentRootAnchor.name}");
    }

    // --- 既存の補助メソッド (PlaceDestination, ClearCurrentRoute等) ---
    // ※ 変更なしのため省略。ただしClearCurrentRouteで _persistentRootAnchor = null; を追加してください。

    public GameObject PlaceDestination(double latitude, double longitude, double altitude, double heading, bool isCorner, Action<GameObject> onComplete)
    {
        if (GeospatialController?.AnchorManager == null) return null;
        
        // 変更: Terrain Anchor を優先して使用する
        // 高さは地形相対 (altitudeAboveTerrain) として AltitudeOffset を使用
        Quaternion rot = Quaternion.Euler(0, (float)heading, 0);

        StartCoroutine(ResolveOnTerrainRoutine(latitude, longitude, rot, isCorner, onComplete));
        return null; // 非同期生成のため null を返す
    }

    private void InstantiateUnderAnchor(GameObject anchorGO, bool isCorner)
    {
        var prefab = (isCorner && CornerPrefab != null) ? CornerPrefab : DestinationPrefab;
        var go = Instantiate(prefab, anchorGO.transform, false);
        go.transform.localPosition = Vector3.zero;
        go.SetActive(true);
    }

    private IEnumerator ResolveOnTerrainRoutine(double lat, double lon, Quaternion rot, bool isCorner, Action<GameObject> onComplete)
    {
        var promise = GeospatialController.AnchorManager.ResolveAnchorOnTerrainAsync(lat, lon, AltitudeOffset, rot);
        yield return promise;
        if (promise.Result.TerrainAnchorState == TerrainAnchorState.Success && promise.Result.Anchor != null)
        {
            InstantiateUnderAnchor(promise.Result.Anchor.gameObject, isCorner);
            onComplete?.Invoke(promise.Result.Anchor.gameObject);
        }
    }

    public void ClearCurrentRoute()
    {
        _persistentRootAnchor = null; // 追加
        if (routeLineRenderer != null)
        {
            routeLineRenderer.gameObject.SetActive(false);
            routeLineRenderer.transform.SetParent(this.transform);
        }
        foreach (var a in _activeAnchors) if (a != null) Destroy(a);
        _activeAnchors.Clear();
        _passedNodeCount = 0;
    }

    public void SetRouteStartCoordinate(double lat, double lon) { _routeStartLat = lat; _routeStartLon = lon; }
    private void UpdateMonitorTarget()
    {
        if (_activeAnchors.Count > 0 && _activeAnchors.First.Value != null)
        {
            bool isLast = (_passedNodeCount >= _fullRoutePath.Count - 1);
            progressMonitor.SetTarget(_activeAnchors.First.Value.transform, _passedNodeCount, isLast);
        }
    }
}