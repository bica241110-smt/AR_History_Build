using TMPro;
using UnityEngine;

public class NavigationGuideUI : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private RouteProgressMonitor progressMonitor; // 監視クラスへの参照
    [SerializeField] private RectTransform arrowIcon;              // 回転させる矢印画像 (UI)
    [SerializeField] private TextMeshProUGUI TargetText;      // 目的地表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI DistanceText;    // 距離表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI DirectionText;   // 方向表示テキスト (UI)

    [Header("Speed Display")]
    [SerializeField] private SpeedCalculator SpeedCalculator; // 計算クラスへの参照
    [SerializeField] private TextMeshProUGUI SpeedText;       // 速度を表示するUI

    [Header("Safety Settings")]
    [SerializeField] private CanvasGroup uiCanvasGroup;          // 透明度操作用
    [SerializeField] private float safetySpeedThreshold = 20.0f; // 閾値
    [SerializeField] private float timeToFade = 3.0f;            // 持続時間
    [SerializeField] private float fadedAlpha = 0.3f;            // 半透明時のアルファ
    [SerializeField] private float fadeSpeed = 5.0f;             // フェード速度

    private Camera _mainCamera;
    private float _highSpeedTimer = 0f;

    private void Start()
    {
        _mainCamera = Camera.main;

    }

    private void Update()
    {
        // ターゲットが存在しない（ゴールした、または準備中）場合は非表示にして戻る
        if (progressMonitor == null || progressMonitor.CurrentTarget == null)
        {
            SetUIActive(false);
            return;
        }

        SetUIActive(true);
        UpdateDirectionInfo();
        UpdateTextUI(); // 毎フレーム呼ばれる想定なのでここで更新（必要なら外部からも呼べる）
        HandleSafetyFade();
    }

    private void SetUIActive(bool isActive)
    {
        // UI全体をCanvasGroupで制御
        if (uiCanvasGroup != null)
        {
            // 非表示時はアルファを即座に0、表示時はHandleSafetyFadeに任せる（または1にする）
            if (!isActive) uiCanvasGroup.alpha = 0f;
            uiCanvasGroup.interactable = isActive;
            uiCanvasGroup.blocksRaycasts = isActive;
        }
    }

    private void UpdateDirectionInfo()
    {
        Transform target = progressMonitor.CurrentTarget;
        Vector3 playerPos = _mainCamera.transform.position;
        Vector3 targetPos = target.position;

        // 1. ターゲットへのベクトルを計算（高さを無視して平面で考える）
        Vector3 directionToTarget = targetPos - playerPos;
        directionToTarget.y = 0; // 高低差を無視

        // 2. カメラの前方ベクトル（高さを無視）
        Vector3 cameraForward = _mainCamera.transform.forward;
        cameraForward.y = 0; // 高低差を無視

        // 3. 角度を計算 (-180度 ～ +180度)
        // Vector3.up を軸にして、カメラの前方からターゲット方向への角度を求める
        // プラスなら右、マイナスなら左
        float signedAngle = Vector3.SignedAngle(cameraForward, directionToTarget, Vector3.up);

        // --- UI更新処理 ---

        // A. 矢印アイコンの回転
        // UIの回転はZ軸で行う。角度は逆になる場合があるためマイナスを調整
        if (arrowIcon != null)
        {
            // UnityのUI回転は反時計回りがプラスなので、-signedAngle を入れると直感的に合うことが多い
            arrowIcon.localEulerAngles = new Vector3(0, 0, -signedAngle);
        }

        float distance = Vector3.Distance(playerPos, targetPos);
        // B. デバッグ表示（必要に応じて）
        DebugTextManager.Set("NavigationGuide", $"方角：{GetDirectionString(signedAngle)}\n次のノードまでの距離： {distance:F1} ");
    }

    /// <summary>
    /// 角度から「右」「左」「直進」などの文字を返す
    /// </summary>
    private string GetDirectionString(float angle)
    {
        // 許容範囲（真正面とみなす角度）
        float threshold = 15f;

        if (Mathf.Abs(angle) <= threshold)
        {
            return "直進";
        }
        else if (angle > threshold && angle < 90f)
        {
            return "斜め右方向";
        }
        else if (angle >= 90f && angle < 170f)
        {
            return "右方向";
        }
        else if (angle < -threshold && angle > -90f)
        {
            return "斜め左方向";
        }
        else if (angle <= -90f && angle > -170f)
        {
            return "左方向";
        }
        else
        {
            return "後ろ方向";
        }
    }

    private void UpdateTextUI()
    {
        // 安全チェック
        if (progressMonitor == null || progressMonitor.CurrentTarget == null) return;

        // 目的地表示
        if (TargetText != null)
        {
            // 修正: アンカー名(GameObjectの名前)ではなく、モニターにセットされた目的地名を表示
            TargetText.text = $"目的地: {progressMonitor.DestinationName}";
        }

        // 現在位置・ターゲット取得（カメラが無い場合は0を使う）
        Vector3 playerPos = _mainCamera != null ? _mainCamera.transform.position : (Camera.main != null ? Camera.main.transform.position : Vector3.zero);
        Vector3 targetPos = progressMonitor.CurrentTarget.position;

        // 水平距離（XZ平面）
        float distanceXZ = Vector2.Distance(
            new Vector2(playerPos.x, playerPos.z),
            new Vector2(targetPos.x, targetPos.z)
        );

        if (DistanceText != null)
        {
            DistanceText.text = $"距離: {distanceXZ:F1} m";
        }

        // 方向（角度とわかりやすい文字）
        Vector3 dir = targetPos - playerPos;
        dir.y = 0;
        Vector3 cameraForward = _mainCamera != null ? _mainCamera.transform.forward : Vector3.forward;
        cameraForward.y = 0;
        float signedAngle = Vector3.SignedAngle(cameraForward, dir, Vector3.up);

        if (DirectionText != null)
        {
            DirectionText.text = $"{GetDirectionString(signedAngle)} ({signedAngle:F0}°)";
        }

        if (SpeedText != null)
        {
            if (SpeedCalculator != null)
            {
                // ここでテキスト書き換えを行う
                SpeedText.text = $"{SpeedCalculator.CurrentKmh:F0} km/h";
            }
            else
            {
                SpeedText.text = "速度: --";
            }
        }
    }

    private void HandleSafetyFade()
    {
        if (SpeedCalculator == null || uiCanvasGroup == null) return;

        // SpeedCalculatorから現在の速度(float)を取得
        float currentKmh = SpeedCalculator.CurrentKmh;

        // 速度判定
        if (currentKmh > safetySpeedThreshold)
        {
            _highSpeedTimer += Time.deltaTime;
        }
        else
        {
            _highSpeedTimer = 0f;
        }

        // フェード処理
        float targetAlpha = (_highSpeedTimer >= timeToFade) ? fadedAlpha : 1.0f;
        uiCanvasGroup.alpha = Mathf.Lerp(uiCanvasGroup.alpha, targetAlpha, Time.deltaTime * fadeSpeed);
        uiCanvasGroup.blocksRaycasts = (uiCanvasGroup.alpha > 0.9f);
    }
}