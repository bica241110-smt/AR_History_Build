using SimpleJSON;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using Google.XR.ARCoreExtensions.Samples.Geospatial;

public class OverpassRequest : MonoBehaviour
{
    public static OverpassRequest Instance { get; private set; }

    public OSRMRouteRequest RouteRequest;

    public static MapTileUI MapTileUI { get; private set; }

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    /// <summary>
    /// ���݈ʒu����Ŋ��̃o�X����������ċ�����\��
    /// </summary>
    public IEnumerator FetchBusStopInfoCoroutine(double latitude, double longitude)
    {
        string query = $@"
        [out:json];
        node(around:2000,{latitude},{longitude})[highway=bus_stop];
        out body;";

        var form = new WWWForm();
        form.AddField("data", query);

        if (TargetRenderer.Instance != null)
        {
            TargetRenderer.Instance.AppendApiLog($"Overpass request payload:\n{query}");
        }

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();

            long responseCode = www.responseCode;
            string responseBody = www.downloadHandler != null ? www.downloadHandler.text : string.Empty;

            if (www.result != UnityWebRequest.Result.Success)
            {
                string err = "API�G���[: " + www.error;
                Debug.LogError(err);

                if (TargetRenderer.Instance != null)
                {
                    string full = $"Overpass ERROR\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nError: {www.error}\nBody:\n{responseBody}";
                    TargetRenderer.Instance.AppendApiLog(full);
                    TargetRenderer.Instance.Display(err);
                }
                yield break;
            }

            string json = responseBody;
            Debug.Log("�擾�����o�X��f�[�^: " + json);

            if (TargetRenderer.Instance != null)
            {
                string full = $"Overpass RESPONSE\nURL: https://overpass-api.de/api/interpreter\nResponseCode: {responseCode}\nBody:\n{json}";
                TargetRenderer.Instance.AppendApiLog(full);
            }

            var parsed = JSON.Parse(json);
            var elements = parsed["elements"];

            if (elements == null || elements.Count == 0)
            {
                if (TargetRenderer.Instance != null)
                    TargetRenderer.Instance.Display("�߂��Ƀo�X�₪������܂���B");
                yield break;
            }

            double nearestDistSq = double.MaxValue;
            double nearestDist = 0.0;
            string nearestName = "���O�Ȃ�";
            double nearestLat = 0, nearestLon = 0;

            for (int i = 0; i < elements.Count; i++)
            {
                var node = elements[i];
                double lat = node["lat"];
                double lon = node["lon"];

                string name = "���O�Ȃ�";
                if (node["tags"] != null && node["tags"]["name"] != null)
                    name = node["tags"]["name"];

                double distSq = GeoCalculator.GetDistanceSquared(latitude, longitude, lat, lon);
                if (distSq < nearestDistSq)
                {
                    nearestDistSq = distSq;
                    nearestName = name;
                    nearestLat = lat;
                    nearestLon = lon;
                }
            }

            nearestDist = GeoCalculator.GetDistance(latitude, longitude, nearestLat, nearestLon);
            double nearestDire = GeoCalculator.GetDirection(latitude, longitude, nearestLat, nearestLon);

            // ==================================================================
            // ������ ��������: �Ŋ��u���H�m�[�h�v�� Overpass �Ŏ擾���� lat/lon ��u�������� ������
            // ==================================================================

            string roadQuery = $@"
            [out:json];
            node(around:200,{latitude},{longitude})[""highway""];
            out body;";

            var form2 = new WWWForm();
            form2.AddField("data", roadQuery);

            using (UnityWebRequest www2 = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form2))
            {
                yield return www2.SendWebRequest();

                string roadJson = www2.downloadHandler.text;

                if (www2.result == UnityWebRequest.Result.Success)
                {
                    var parsed2 = JSON.Parse(roadJson);
                    var roads = parsed2["elements"];

                    if (roads != null && roads.Count > 0)
                    {
                        // �Ŋ�蓹�H�m�[�h��T��
                        double bestDistSq = double.MaxValue;
                        for (int i = 0; i < roads.Count; i++)
                        {
                            double rlat = roads[i]["lat"];
                            double rlon = roads[i]["lon"];

                            double dist = GeoCalculator.GetDistanceSquared(latitude, longitude, rlat, rlon);
                            if (dist < bestDistSq)
                            {
                                bestDistSq = dist;
                                latitude = rlat;   // �������ϐ�����������
                                longitude = rlon;   // �������ϐ�����������
                            }
                        }
                    }
                }
            }

            // ==================================================================
            // ������ �����܂� Roads Overpass �ǉ����� ������
            // ==================================================================

            // ���̎��_�� nearestLat / nearestLon �́u���H�m�[�h�v�ɍX�V�ς�

            if (RouteRequest != null)
            {
                yield return StartCoroutine(RouteRequest.GetRoute(
                    longitude, latitude, nearestLon, nearestLat,
                    (routePoints) =>
                    {
                        // routePoints �Ɉܓx�o�x���X�g�������Ă���
                    }));
            }

            // ==================================================================
            // �� ���������Ȃ��̎w�肵���ʒu�F�u���ʂ� TargetRenderer �ɕ\���v���O�ł� ��
            // ==================================================================

            var geoCtrl = UnityEngine.Object.FindFirstObjectByType<Google.XR.ARCoreExtensions.Samples.Geospatial.GeospatialController>();
            if (geoCtrl != null)
            {
                geoCtrl.PlaceDestinationFromLatLon(longitude, latitude, double.NaN, nearestDire);
            }

            if (TargetRenderer.Instance != null)
            {
                TargetRenderer.Instance.DisplayBusStop(
                    latitude,
                    longitude,
                    nearestName,
                    nearestDist,
                    nearestDire,
                    nearestLat,
                    nearestLon);

                if (RouteRequest != null)
                {
                    yield return StartCoroutine(MapTileUI.LoadMapTile(longitude, latitude));
                    yield return StartCoroutine(RouteRequest.GetRoute(longitude, latitude, nearestLon, nearestLat));
                }
            }
        }
    }
}