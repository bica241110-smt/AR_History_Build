using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(LineRenderer))]
public class RouteLineRenderer : MonoBehaviour
{
    private LineRenderer lineRenderer;

    void Awake()
    {
        lineRenderer = GetComponent<LineRenderer>();

        // ��{�ݒ�i�K�v�ɉ����Ē����j
        lineRenderer.startWidth = 0.2f;
        lineRenderer.endWidth = 0.2f;
        lineRenderer.material = new Material(Shader.Find("Unlit/Color"));
        lineRenderer.material.color = Color.cyan;
        lineRenderer.positionCount = 0;
        lineRenderer.useWorldSpace = true;
    }

    /// <summary>
    /// �o�H�_�i���E���W�j��n���Đ���`�悵�܂��B
    /// </summary>
    public void DrawRoute(List<Vector3> worldPositions)
    {
        if (worldPositions == null || worldPositions.Count < 2)
        {
            Debug.LogWarning("DrawRoute: �_������܂���B");
            return;
        }

        lineRenderer.positionCount = worldPositions.Count;
        lineRenderer.SetPositions(worldPositions.ToArray());
    }
}
