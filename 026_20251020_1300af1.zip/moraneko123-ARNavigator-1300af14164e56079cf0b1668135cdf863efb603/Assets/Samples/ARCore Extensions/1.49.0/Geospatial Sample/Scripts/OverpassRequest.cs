using SimpleJSON;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

public class OverpassRequest : MonoBehaviour
{
    public static OverpassRequest Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    /// <summary>
    /// ���݈ʒu����Ŋ��̃o�X����������ċ�����\��
    /// </summary>
    public static IEnumerator FetchBusStopInfo(double latitude, double longitude)
    {
        string query = $@"
        [out:json];
        node(around:2000,{latitude},{longitude})[highway=bus_stop];
        out body;";

        WWWForm form = new WWWForm();
        form.AddField("data", query);

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                string err = "API�G���[: " + www.error;
                Debug.LogError(err);
                // �\���� TargetRenderer �ɈϏ��i�D�揇: TargetRenderer.Instance -> Instance.targetRenderer�j
                if (TargetRenderer.Instance != null)
                    TargetRenderer.Instance.Display(err);
                else if (Instance != null && TargetRenderer.Instance != null)
                    TargetRenderer.Instance.Display(err);
                yield break;
            }

            string json = www.downloadHandler.text;
            Debug.Log("�擾�����o�X��f�[�^: " + json);

            // JSON���
            var parsed = JSON.Parse(json);
            var elements = parsed["elements"];

            if (elements == null || elements.Count == 0)
            {
                string msg = "�߂��Ƀo�X�₪������܂���B";
                if (TargetRenderer.Instance != null)
                    TargetRenderer.Instance.Display(msg);
                else if (Instance != null && TargetRenderer.Instance != null)
                    TargetRenderer.Instance.Display(msg);
                yield break;
            }

            // �Ŋ��̃o�X���T��
            double nearestDist = double.MaxValue;
            string nearestName = "���O�Ȃ�";
            double nearestLat = 0, nearestLon = 0;

            for (int i = 0; i < elements.Count; i++)
            {
                var node = elements[i];
                double lat = node["lat"];
                double lon = node["lon"];
                string name = "���O�Ȃ�";
                if (node["tags"] != null && node["tags"]["name"] != null)
                    name = node["tags"]["name"];

                double dist = GeoCalculator.GetDistance(latitude, longitude, lat, lon);
                if (dist < nearestDist)
                {
                    nearestDist = dist;
                    nearestName = name;
                    nearestLat = lat;
                    nearestLon = lon;
                }
            }

            double direction = GeoCalculator.GetDirection(latitude, longitude, nearestLat, nearestLon);

            // ���ʂ� TargetRenderer �ɕ\��
            if (TargetRenderer.Instance != null)
            {
                TargetRenderer.Instance.DisplayBusStop(nearestName, nearestDist, nearestLat, nearestLon);
            }
            else if (Instance != null && TargetRenderer.Instance != null)
            {
                TargetRenderer.Instance.DisplayBusStop(nearestName, nearestDist, nearestLat, nearestLon);
            }
            else
            {
                string result = $"�Ŋ��̃o�X��: {nearestName}\n" +
                                $"����: {nearestDist:F1} m\n" +
                                $"����: {direction:F1}��\n" +
                                $"���W: ({nearestLat}, {nearestLon})";
                Debug.Log(result);
            }
        }
    }
}