using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using SimpleJSON;

public class OverpassRequest : MonoBehaviour
{
    public static OverpassRequest instance { get; private set; }

    public RouteRequest routeRequest;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public IEnumerator FetchBusStopInfoCoroutine(double latitude, double longitude)
    {
        // 1) 近くの道路を探す（バス停検索の起点にするため）
        // ※ルートの始点には「現在地(latitude, longitude)」を使うため、ここでの結果は検索用
        double searchBaseLat = latitude;
        double searchBaseLon = longitude;

        yield return StartCoroutine(FetchNearestRoadNodeCoroutine(latitude, longitude, (rLat, rLon) =>
        {
            searchBaseLat = rLat;
            searchBaseLon = rLon;
            DebugTextManager.Log("Info", $"Search base node: ({rLat}, {rLon})");
        }));

        // 2) その道路ノード周辺から最寄りのバス停を取得
        bool foundBus = false;
        string busName = "名前なし";
        double busLat = 0, busLon = 0;

        yield return StartCoroutine(FetchNearestBusStopFromNodeCoroutine(searchBaseLat, searchBaseLon, (bLat, bLon, name) =>
        {
            foundBus = true;
            busLat = bLat;
            busLon = bLon;
            busName = name;
            DebugTextManager.Log("Info", $"Nearest bus stop: {busName}");
        }));

        if (!foundBus)
        {
            DebugTextManager.Log("Info", "No bus stop found nearby.");
            yield break;
        }

        // 3) 結果を用いてルート取得
        // ★修正: 始点は「現在地(latitude, longitude)」を使用し、終点は「バス停」
        yield return StartCoroutine(HandleRouteCoroutine(latitude, longitude, busLat, busLon, busName));
    }

    // ... (FetchNearestRoadNodeCoroutine は変更なし) ...
    public IEnumerator FetchNearestRoadNodeCoroutine(double latitude, double longitude, Action<double, double> onComplete)
    {
        // 車道だけでなく歩道も含むが、あくまで「バス停を探す中心点」として使うならOK
        string roadQuery = $@"
        [out:json];
        node(around:200,{latitude},{longitude})[""highway""];
        out body;";

        var form = new WWWForm();
        form.AddField("data", roadQuery);

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success)
            {
                onComplete?.Invoke(latitude, longitude);
                yield break;
            }
            var parsed = JSON.Parse(www.downloadHandler.text);
            var roads = parsed["elements"];
            if (roads == null || roads.Count == 0)
            {
                onComplete?.Invoke(latitude, longitude);
                yield break;
            }

            double bestDistSq = double.MaxValue;
            double bestLat = latitude;
            double bestLon = longitude;

            for (int i = 0; i < roads.Count; i++)
            {
                double rlat = roads[i]["lat"];
                double rlon = roads[i]["lon"];
                double distSq = GeoCalculator.GetDistanceSquared(latitude, longitude, rlat, rlon);
                if (distSq < bestDistSq)
                {
                    bestDistSq = distSq;
                    bestLat = rlat;
                    bestLon = rlon;
                }
            }
            onComplete?.Invoke(bestLat, bestLon);
        }
    }

    // ... (FetchNearestBusStopFromNodeCoroutine は変更なし) ...
    public IEnumerator FetchNearestBusStopFromNodeCoroutine(double nodeLat, double nodeLon, Action<double, double, string> onComplete)
    {
        string query = $@"
        [out:json];
        node(around:2000,{nodeLat},{nodeLon})[highway=bus_stop];
        out body;";

        var form = new WWWForm();
        form.AddField("data", query);

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success) yield break;

            var parsed = JSON.Parse(www.downloadHandler.text);
            var elements = parsed["elements"];
            if (elements == null || elements.Count == 0) yield break;

            double nearestDistSq = double.MaxValue;
            string nearestName = "名前なし";
            double nearestLat = 0, nearestLon = 0;

            for (int i = 0; i < elements.Count; i++)
            {
                var node = elements[i];
                double lat = node["lat"];
                double lon = node["lon"];
                string name = (node["tags"] != null && node["tags"]["name"] != null) ? node["tags"]["name"] : "名前なし";

                double distSq = GeoCalculator.GetDistanceSquared(nodeLat, nodeLon, lat, lon);
                if (distSq < nearestDistSq)
                {
                    nearestDistSq = distSq;
                    nearestName = name;
                    nearestLat = lat;
                    nearestLon = lon;
                }
            }
            onComplete?.Invoke(nearestLat, nearestLon, nearestName);
        }
    }

    /// <summary>
    /// startLat/Lon: 現在地
    /// targetLat/Lon: 目的地
    /// </summary>
    public IEnumerator HandleRouteCoroutine(double startLat, double startLon, double targetLat, double targetLon, string name)
    {
        double distance = GeoCalculator.GetDistance(startLat, startLon, targetLat, targetLon);
        double direction = GeoCalculator.GetDirection(startLat, startLon, targetLat, targetLon);

        // GeospatialController に目的地を配置（矢印用アンカーなど）
        var geoCtrl = UnityEngine.Object.FindFirstObjectByType<Google.XR.ARCoreExtensions.Samples.Geospatial.GeospatialController>();
        if (geoCtrl != null)
        {
            // 注: PlaceDestinationFromLatLon が古い座標系ロジックを使っている場合は修正が必要かもしれませんが、
            // 今回はRouteLineが主目的なのでそのままにします。
            geoCtrl.PlaceDestinationFromLatLon(targetLon, targetLat, double.NaN, direction);
        }

        string busInfo =
            $"目的地: {name}\n" +
            $"直線距離: {distance:F1} m\n" +
            $"座標: ({targetLat:F6}, {targetLon:F6})";

        DebugTextManager.Set("BusStop", busInfo);

        if (routeRequest != null)
        {
            // ★修正: 二重呼び出しを削除し、ここでのみ呼び出す
            // 現在地(start) -> バス停(target) へのルートをリクエスト
            yield return StartCoroutine(routeRequest.RequestRouteAndPlace(startLat, startLon, targetLat, targetLon, name));
        }
    }
}