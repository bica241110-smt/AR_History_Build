using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class NavigationGuideUI : MonoBehaviour
{
    [Header("UI Panels")]
    [SerializeField] private GameObject setupPanel;   // 目的地入力や決定ボタンを含むパネル
    [SerializeField] private GameObject guidePanel;   // 矢印や距離表示を含むナビパネル
    [SerializeField] private GameObject debugPanel;   // デバッグ情報表示パネル
    [SerializeField] private GameObject searchPanel;   // 検索系UIパネル
    [SerializeField] private GameObject ARviewPanel;   // デバッグ情報表示パネル

    [Header("References")]
    [SerializeField] private RouteProgressMonitor progressMonitor; // 監視クラスへの参照
    [SerializeField] private RectTransform arrowIcon;              // 回転させる矢印画像 (UI)
    [SerializeField] private TextMeshProUGUI targetText;      // 目的地表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI distanceText;    // 距離表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI timeText;   // 時刻表示テキスト (UI)
    [SerializeField] private TextMeshProUGUI warnText;   // 警告表示テキスト (UI)

    [Header("Speed Display")]
    [SerializeField] private SpeedCalculator SpeedCalculator; // 計算クラスへの参照
    [SerializeField] private TextMeshProUGUI speedText;       // 速度を表示するUI

    [Header("Safety Settings")]
    [SerializeField] private CanvasGroup uiCanvasGroup;          // 透明度操作用
    [SerializeField] private float safetySpeedThreshold = 20.0f; // 閾値
    [SerializeField] private float timeToFade = 3.0f;            // 持続時間
    [SerializeField] private float fadedAlpha = 0.3f;            // 半透明時のアルファ
    [SerializeField] private float fadeSpeed = 5.0f;             // フェード速度

    [Header("Debug Settings")]
    [SerializeField] private Button DebugButton; // デバッグパネル表示切替ボタン

    [Header("Update Settings")]
    [SerializeField] private float uiUpdateInterval = 0.5f; // 更新間隔
    private float _uiUpdateTimer = 0f;

    public bool isDebugPanelVisible { get; private set; } = false;

    private Camera _mainCamera;
    private float _highSpeedTimer = 0f;

    private void Start()
    {
        if (Camera.main != null)
        {
            _mainCamera = Camera.main;
        }

        // --- 追記：ボタンのクリックイベントを登録 ---
        if (DebugButton != null)
        {
            DebugButton.onClick.AddListener(ToggleDebugPanels);
        }

        // 初期状態を反映（起動時は非表示にする場合）
        SetDebugPanelsVisible(isDebugPanelVisible);
        UpdateTimeDisplay();
    }

    private void Update()
    {
        //// 1. 目的地があるかどうかでパネルを切り替える
        //bool isNavigating = progressMonitor != null && progressMonitor.IsNavigating;

        //// if (setupPanel != null) setupPanel.SetActive(!isNavigating);
        //if (guidePanel != null) guidePanel.SetActive(isNavigating);

        //// 2. 速度による「画面全体のフェード処理」
        //// 目的地設定中であっても、速度が出ていれば半透明になります
        //HandleSafetyFade();

        //// テストコード
        //// 案内中でなくても、速度だけは常に更新して確認できるようにする
        //if (speedText != null && SpeedCalculator != null)
        //{
        //    speedText.text = $"{SpeedCalculator.CurrentKmh:F0} km/h";
        //}

        //// 3. 目的地がある場合のみ、ナビゲーション情報を更新
        //if (isNavigating)
        //{
        //    UpdateDirectionInfo();
        //    // 4. テキスト情報の更新（タイマー制御：0.5秒ごと）
        //    _uiUpdateTimer += Time.deltaTime;
        //    if (_uiUpdateTimer >= uiUpdateInterval)
        //    {
        //        UpdateTextUI(); // 内部で _lastSignedAngle などを利用
        //        _uiUpdateTimer = 0f;
        //    }
        //}

        if (progressMonitor == null || !progressMonitor.IsNavigating)
        {
            if (guidePanel.activeSelf) guidePanel.SetActive(false);
            return;
        }

        if (!guidePanel.activeSelf)
        {
            guidePanel.SetActive(true);
            // 案内開始時に一度だけ目的地名を表示
            if (targetText != null) targetText.text = $"目的地: {progressMonitor.DestinationName}";
        }

        // 1. 矢印の回転（カメラの向きに即座に反応させるため毎フレーム）
        UpdateArrowRotation();

        // 2. 安全フェード処理（滑らかさのため毎フレーム）
        HandleSafetyFade();

        // 3. 0.5秒ごとのテキスト更新
        _uiUpdateTimer += Time.deltaTime;
        if (_uiUpdateTimer >= uiUpdateInterval)
        {
            UpdateIntervalUI();
            _uiUpdateTimer = 0f;
        }
    }

    //private (float signedAngle, float distance) CalculateNavigationData()
    //{
    //    if (progressMonitor == null || progressMonitor.CurrentTarget == null)
    //    {
    //        return (0, 0);
    //    }

    //    Vector3 playerPos = _mainCamera != null ? _mainCamera.transform.position : Vector3.zero;
    //    Vector3 targetPos = progressMonitor.CurrentTarget.position;

    //    // ターゲットへの方向ベクトル
    //    Vector3 directionToTarget = targetPos - playerPos;
    //    directionToTarget.y = 0;

    //    // カメラの前方ベクトル
    //    Vector3 cameraForward = _mainCamera != null ? _mainCamera.transform.forward : Vector3.forward;
    //    cameraForward.y = 0;

    //    // SignedAngleの計算
    //    float signedAngle = Vector3.SignedAngle(cameraForward, directionToTarget, Vector3.up);

    //    // 距離の計算
    //    float distance = Vector3.Distance(playerPos, targetPos);

    //    return (signedAngle, distance);
    //}

    //private void UpdateDirectionInfo()
    //{
    //    var (signedAngle, distance) = CalculateNavigationData();

    //    // 矢印アイコンの回転
    //    if (arrowIcon != null)
    //    {
    //        arrowIcon.localEulerAngles = new Vector3(0, 0, -signedAngle);
    //    }

    //    // デバッグ表示
    //    DebugTextManager.Set("NavigationGuide", $"方角：{GetDirectionString(signedAngle)}\n次のノードまでの距離： {distance:F1} ");
    //}

    /// <summary>
    /// 角度から「右」「左」「直進」などの文字を返す
    /// </summary>
    //private string GetDirectionString(float angle)
    //{
    //    // 許容範囲（真正面とみなす角度）
    //    float threshold = 15f;

    //    if (Mathf.Abs(angle) <= threshold)
    //    {
    //        return "直進";
    //    }
    //    else if (angle > threshold && angle < 90f)
    //    {
    //        return "斜め右方向";
    //    }
    //    else if (angle >= 90f && angle < 170f)
    //    {
    //        return "右方向";
    //    }
    //    else if (angle < -threshold && angle > -90f)
    //    {
    //        return "斜め左方向";
    //    }
    //    else if (angle <= -90f && angle > -170f)
    //    {
    //        return "左方向";
    //    }
    //    else
    //    {
    //        return "後ろ方向";
    //    }
    //}
    //private void UpdateTextUI()
    //{
    //    var (signedAngle, distance) = CalculateNavigationData();

    //    // 目的地表示
    //    if (targetText != null)
    //    {
    //        targetText.text = $"目的地: {progressMonitor.DestinationName}";
    //    }

    //    // 距離表示
    //    //if (distanceText != null)
    //    //{
    //    //    distanceText.text = $"距離: {distance:F1} m";
    //    //}

    //    // 方向表示
    //    if (directionText != null)
    //    {
    //        directionText.text = $"{GetDirectionString(signedAngle)} ({signedAngle:F0}°)";
    //    }

    //    // 速度表示
    //    if (speedText != null)
    //    {
    //        speedText.text = SpeedCalculator != null ? $"{SpeedCalculator.CurrentKmh:F0} km/h" : "速度: --";
    //    }
    //}

    private void HandleSafetyFade()
    {
        if (SpeedCalculator == null || uiCanvasGroup == null) return;

        // SpeedCalculatorから現在の速度(float)を取得
        float currentKmh = SpeedCalculator.CurrentKmh;

        // 速度判定
        if (currentKmh > safetySpeedThreshold)
        {
            _highSpeedTimer += Time.deltaTime;
        }
        else
        {
            _highSpeedTimer = 0f;
        }

        // フェード処理
        bool isDangerSpeed = (_highSpeedTimer >= timeToFade);
        float targetAlpha = isDangerSpeed ? fadedAlpha : 1.0f;
        uiCanvasGroup.alpha = Mathf.Lerp(uiCanvasGroup.alpha, targetAlpha, Time.deltaTime * fadeSpeed);
        uiCanvasGroup.blocksRaycasts = !isDangerSpeed;

        if (searchPanel != null)
        {
            // パネルの現在の表示状態と、安全状態の不一致をチェック
            // (危険状態ならSetActive(false)に、安全状態ならSetActive(true)にする)
            bool shouldBeActive = !isDangerSpeed;
            if (searchPanel.activeSelf != shouldBeActive)
            {
                searchPanel.SetActive(shouldBeActive);
            }
        }
    }

    private void UpdateArrowRotation()
    {
        if (arrowIcon == null || progressMonitor.CurrentTarget == null) return;

        Vector3 playerPos = _mainCamera.transform.position;
        Vector3 targetPos = progressMonitor.CurrentTarget.position;

        Vector3 directionToTarget = targetPos - playerPos;
        directionToTarget.y = 0;

        Vector3 cameraForward = _mainCamera.transform.forward;
        cameraForward.y = 0;

        float signedAngle = Vector3.SignedAngle(cameraForward, directionToTarget, Vector3.up);

        // 矢印を回転
        arrowIcon.localEulerAngles = new Vector3(0, 0, -signedAngle);
    }

    private void UpdateIntervalUI()
    {
        // ① 時刻の更新
        UpdateTimeDisplay();

        // ② 次のノードまでの距離更新
        if (distanceText != null && progressMonitor.CurrentTarget != null)
        {
            float dist = Vector3.Distance(_mainCamera.transform.position, progressMonitor.CurrentTarget.position);
            distanceText.text = $"次の地点まで: {dist:F0}m";
        }

        // ③ 速度の更新
        //if (speedText != null && SpeedCalculator != null)
        //{
        //    speedText.text = $"{SpeedCalculator.CurrentKmh:F0} km/h";
        //}
    }

    /// <summary>
    /// 精度状態を更新し、変化があった場合のみUIを切り替える
    /// </summary>
    public void UpdateAccuracyDisplay(bool isAccurate, bool isTracking)
    {
        if (warnText != null)
        {
            // トラッキング中で、かつ精度が低い場合のみ警告を表示
            if (isTracking && isAccurate)
            {
                warnText.gameObject.SetActive(false);
            } else
            {
                warnText.text = $"<color=yellow>精度が不足しています。周囲を見回してください。</color>";
                warnText.gameObject.SetActive(true);
            }
        }
    }

    // --- 追記：表示・非表示を切り替えるメソッド ---
    public void ToggleDebugPanels()
    {
        // 状態を反転
        isDebugPanelVisible = !isDebugPanelVisible;

        // パネルの表示状態を更新
        SetDebugPanelsVisible(isDebugPanelVisible);
    }

    private void SetDebugPanelsVisible(bool visible)
    {
        if (debugPanel != null) debugPanel.SetActive(visible);
        if (ARviewPanel != null) ARviewPanel.SetActive(visible);

        // ボタンのテキストや色を変えたい場合はここに追記
        // 例: DebugButton.GetComponentInChildren<TextMeshProUGUI>().text = visible ? "Hide Debug" : "Show Debug";
    }

    public void UpdateDistanceDisplay(float distanceInMeters)
    {
        if (distanceInMeters >= 1000f)
        {
            // 1km以上は「1.2 km」のように表示
            float distanceInKm = distanceInMeters / 1000f;
            distanceText.text = $"残り {distanceInKm:F1} km";
        }
        else
        {
            // 1km未満は「350 m」のように表示
            distanceText.text = $"残り {Mathf.CeilToInt(distanceInMeters)} m";
        }
    }

    private void UpdateTimeDisplay()
    {
        if (timeText != null)
        {
            // "14:30" 形式で表示
            timeText.text = DateTime.Now.ToString("HH:mm");
        }
    }
}