using Google.XR.ARCoreExtensions;
using Google.XR.ARCoreExtensions.Samples.Geospatial;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class DestinationMeshPlacer : MonoBehaviour
{
    public GeospatialController GeospatialController;
    public GameObject DestinationPrefab;
    public GameObject CornerPrefab;

    [Tooltip("地面からの高さオフセット (例: 0なら地面、0.2なら少し浮く)")]
    public float AltitudeOffset = 0f;
    public float ScaleFactorPerMeter = 0.1f;
    public RouteLineRenderer routeLineRenderer;

    [Header("Dynamic Route Settings")]
    public RouteProgressMonitor progressMonitor;
    public const int MAX_ACTIVE_ANCHORS = 20;

    private List<Vector2d> _fullRoutePath;
    private LinkedList<GameObject> _activeAnchors = new LinkedList<GameObject>();
    private int _nextSpawnIndex = 0;
    private int _passedNodeCount = 0;

    private float DeviceHeightOffset = 1.5f;
    private double _routeStartLat = double.NaN;
    private double _routeStartLon = double.NaN;

    // --- 修正①: Update() とタイマー変数を削除しました ---

    public void StartDynamicRoute(List<Vector2d> routePoints)
    {
        if (routePoints == null || routePoints.Count == 0) return;
        ClearCurrentRoute();

        _fullRoutePath = routePoints;
        _nextSpawnIndex = 0;
        _passedNodeCount = 0;

        progressMonitor.OnTargetReached -= OnNextAnchorReached;
        progressMonitor.OnTargetReached += OnNextAnchorReached;

        int initialCount = Mathf.Min(MAX_ACTIVE_ANCHORS, _fullRoutePath.Count);
        for (int i = 0; i < initialCount; i++)
        {
            SpawnNextAnchor();
        }

        UpdateMonitorTarget();

        if (double.IsNaN(_routeStartLat))
        {
            SetRouteStartCoordinate(routePoints[0].y, routePoints[0].x);
        }

        // 最初のアンカーが生成された後に描画指示
        UpdateRouteLineFromAnchors();
    }

    private void OnNextAnchorReached(int passedIndex, bool isGoal)
    {
        if (isGoal)
        {
            DebugTextManager.Set("Destination", "目的地に到着しました！");
            progressMonitor.StopMonitoring();
            return;
        }

        if (_activeAnchors.Count > 0)
        {
            GameObject passedAnchor = _activeAnchors.First.Value;
            _activeAnchors.RemoveFirst();
            if (passedAnchor != null) Destroy(passedAnchor);
        }

        _passedNodeCount++;
        SpawnNextAnchor();
        UpdateMonitorTarget();
        
        // 修正: アンカーが更新された直後に描画
        UpdateRouteLineFromAnchors();
    }

    private void SpawnNextAnchor()
    {
        if (_fullRoutePath == null || _nextSpawnIndex >= _fullRoutePath.Count) return;

        Vector2d p = _fullRoutePath[_nextSpawnIndex];
        double heading = 0.0;
        if (_nextSpawnIndex > 0)
        {
            Vector2d prev = _fullRoutePath[_nextSpawnIndex - 1];
            heading = GeoCalculator.GetDirection(prev.y, prev.x, p.y, p.x);
        }

        GameObject newAnchor = PlaceDestination(p.y, p.x, double.NaN, heading, false, (asyncAnchor) =>
        {
            if (asyncAnchor != null && !_activeAnchors.Contains(asyncAnchor))
            {
                _activeAnchors.AddLast(asyncAnchor);
                // --- 修正: 地形アンカーが解決(Resolve)されたタイミングで線を更新 ---
                UpdateRouteLineFromAnchors();
            }
        });

        if (newAnchor != null && !_activeAnchors.Contains(newAnchor))
        {
            _activeAnchors.AddLast(newAnchor);
            // 即時生成時も更新
            UpdateRouteLineFromAnchors();
        }

        _nextSpawnIndex++;
    }

/// <summary>
/// アンカーのリストから経路の線を更新する
/// カメラに最も近い確定済アンカーを基準(Root)に採用する
/// </summary>
public void UpdateRouteLineFromAnchors()
{
    if (routeLineRenderer == null || _activeAnchors.Count < 2) return;

    var earth = GeospatialController.EarthManager;
    if (earth.EarthTrackingState != TrackingState.Tracking) return;

    // --- 1. 確定済（座標が(0,0,0)でない）アンカーのみを抽出 ---
    List<GameObject> confirmedAnchors = new List<GameObject>();
    foreach (var a in _activeAnchors)
    {
        if (a != null && a.transform.position != Vector3.zero)
        {
            confirmedAnchors.Add(a);
        }
    }

    // 確定したアンカーが2つ以上ない場合は描画できないため中断
    if (confirmedAnchors.Count < 2)
    {
        DebugTextManager.Log("Line", "確定アンカーが不足しています...");
        return;
    }

    // --- 2. カメラから最も近いアンカーを rootAnchor に選定 ---
    Vector3 cameraPos = Camera.main.transform.position;
    GameObject closestAnchor = null;
    float minDistance = float.MaxValue;

    foreach (var a in confirmedAnchors)
    {
        float dist = Vector3.Distance(cameraPos, a.transform.position);
        if (dist < minDistance)
        {
            minDistance = dist;
            closestAnchor = a;
        }
    }

    if (closestAnchor == null) return;
    GameObject rootAnchor = closestAnchor;

    // --- 3. LineRendererを基準アンカーに固定 ---
    // 親が変わった場合のみ SetParent を実行（パフォーマンス対策）
    if (routeLineRenderer.transform.parent != rootAnchor.transform)
    {
        routeLineRenderer.transform.SetParent(rootAnchor.transform, false);
        routeLineRenderer.transform.localPosition = Vector3.zero;
        routeLineRenderer.transform.localRotation = Quaternion.identity;
    }

    // --- 4. 全てのアンカー位置を基準アンカーからのローカル座標に変換 ---
    List<Vector3> localPositions = new List<Vector3>();
    foreach (var anchorGO in confirmedAnchors)
    {
        // rootAnchor自身は Vector3.zero になる
        Vector3 localPos = rootAnchor.transform.InverseTransformPoint(anchorGO.transform.position);
        localPositions.Add(localPos);
    }

    // --- 5. 描画実行 ---
    routeLineRenderer.gameObject.SetActive(true);
    routeLineRenderer.DrawRouteLocal(localPositions);

    DebugTextManager.Log("Line", 
        $"描画更新: {localPositions.Count}点 / Root: {rootAnchor.name} (Camera近傍)");
}

    // --- 補助メソッド群 ---

    public GameObject PlaceDestination(double latitude, double longitude, double altitude, double heading, bool isCorner, Action<GameObject> onComplete)
    {
        if (GeospatialController?.AnchorManager == null) return null;

        var pose = GeospatialController.EarthManager.CameraGeospatialPose;
        double useAlt = double.IsNaN(altitude) ? pose.Altitude : altitude;
        double targetAltitude = useAlt + AltitudeOffset - DeviceHeightOffset;
        Quaternion rot = Quaternion.Euler(0, (float)heading, 0);

        var anchor = GeospatialController.AnchorManager.AddAnchor(latitude, longitude, targetAltitude, rot);
        if (anchor != null)
        {
            InstantiateUnderAnchor(anchor.gameObject, isCorner);
            onComplete?.Invoke(anchor.gameObject);
            return anchor.gameObject;
        }
        else
        {
            StartCoroutine(ResolveOnTerrainRoutine(latitude, longitude, rot, isCorner, onComplete));
            return null;
        }
    }

    private void InstantiateUnderAnchor(GameObject anchorGO, bool isCorner)
    {
        var prefab = (isCorner && CornerPrefab != null) ? CornerPrefab : DestinationPrefab;
        var go = Instantiate(prefab, anchorGO.transform, false);
        go.transform.localPosition = Vector3.zero;
        go.SetActive(true);
    }

    private IEnumerator ResolveOnTerrainRoutine(double lat, double lon, Quaternion rot, bool isCorner, Action<GameObject> onComplete)
    {
        var promise = GeospatialController.AnchorManager.ResolveAnchorOnTerrainAsync(lat, lon, AltitudeOffset, rot);
        yield return promise;
        if (promise.Result.TerrainAnchorState == TerrainAnchorState.Success && promise.Result.Anchor != null)
        {
            InstantiateUnderAnchor(promise.Result.Anchor.gameObject, isCorner);
            onComplete?.Invoke(promise.Result.Anchor.gameObject);
        }
    }

    public void ClearCurrentRoute()
    {
        if (routeLineRenderer != null)
        {
            routeLineRenderer.gameObject.SetActive(false);
            routeLineRenderer.transform.SetParent(this.transform); // 親を一時的に戻す
        }
        foreach (var a in _activeAnchors) if (a != null) Destroy(a);
        _activeAnchors.Clear();
        _passedNodeCount = 0;
    }

    public void SetRouteStartCoordinate(double lat, double lon)
    {
        _routeStartLat = lat; _routeStartLon = lon;
    }

    private void UpdateMonitorTarget()
    {
        if (_activeAnchors.Count > 0 && _activeAnchors.First.Value != null)
        {
            bool isLast = (_passedNodeCount >= _fullRoutePath.Count - 1);
            progressMonitor.SetTarget(_activeAnchors.First.Value.transform, _passedNodeCount, isLast);
        }
    }
}