using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using SimpleJSON;

public class OverpassRequest : MonoBehaviour
{
    public static OverpassRequest instance { get; private set; }

    public RouteRequest routeRequest;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public IEnumerator FetchBusStopInfoCoroutine(double latitude, double longitude)
    {
        // 1) �߂��̓��H��T���i�o�X�⌟���̋N�_�ɂ��邽�߁j
        // �����[�g�̎n�_�ɂ́u���ݒn(latitude, longitude)�v���g�����߁A�����ł̌��ʂ͌����p
        double searchBaseLat = latitude;
        double searchBaseLon = longitude;

        yield return StartCoroutine(FetchNearestRoadNodeCoroutine(latitude, longitude, (rLat, rLon) =>
        {
            searchBaseLat = rLat;
            searchBaseLon = rLon;
            DebugTextManager.Log("Info", $"Search base node: ({rLat}, {rLon})");
        }));

        // 2) ���̓��H�m�[�h���ӂ���Ŋ��̃o�X����擾
        bool foundBus = false;
        string busName = "���O�Ȃ�";
        double busLat = 0, busLon = 0;

        yield return StartCoroutine(FetchNearestBusStopFromNodeCoroutine(searchBaseLat, searchBaseLon, (bLat, bLon, name) =>
        {
            foundBus = true;
            busLat = bLat;
            busLon = bLon;
            busName = name;
            DebugTextManager.Log("Info", $"Nearest bus stop: {busName}");
        }));

        if (!foundBus)
        {
            DebugTextManager.Log("Info", "No bus stop found nearby.");
            yield break;
        }

        // 3) ���ʂ�p���ă��[�g�擾
        // ���C��: �n�_�́u���ݒn(latitude, longitude)�v���g�p���A�I�_�́u�o�X��v
        yield return StartCoroutine(HandleRouteCoroutine(latitude, longitude, busLat, busLon, busName));
    }

    // ... (FetchNearestRoadNodeCoroutine �͕ύX�Ȃ�) ...
    public IEnumerator FetchNearestRoadNodeCoroutine(double latitude, double longitude, Action<double, double> onComplete)
    {
        // �ԓ������łȂ��������܂ނ��A�����܂Łu�o�X���T�����S�_�v�Ƃ��Ďg���Ȃ�OK
        string roadQuery = $@"
        [out:json];
        node(around:200,{latitude},{longitude})[""highway""];
        out body;";

        var form = new WWWForm();
        form.AddField("data", roadQuery);

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success)
            {
                onComplete?.Invoke(latitude, longitude);
                yield break;
            }
            var parsed = JSON.Parse(www.downloadHandler.text);
            var roads = parsed["elements"];
            if (roads == null || roads.Count == 0)
            {
                onComplete?.Invoke(latitude, longitude);
                yield break;
            }

            double bestDistSq = double.MaxValue;
            double bestLat = latitude;
            double bestLon = longitude;

            for (int i = 0; i < roads.Count; i++)
            {
                double rlat = roads[i]["lat"];
                double rlon = roads[i]["lon"];
                double distSq = GeoCalculator.GetDistanceSquared(latitude, longitude, rlat, rlon);
                if (distSq < bestDistSq)
                {
                    bestDistSq = distSq;
                    bestLat = rlat;
                    bestLon = rlon;
                }
            }
            onComplete?.Invoke(bestLat, bestLon);
        }
    }

    // ... (FetchNearestBusStopFromNodeCoroutine �͕ύX�Ȃ�) ...
    public IEnumerator FetchNearestBusStopFromNodeCoroutine(double nodeLat, double nodeLon, Action<double, double, string> onComplete)
    {
        string query = $@"
        [out:json];
        node(around:2000,{nodeLat},{nodeLon})[highway=bus_stop];
        out body;";

        var form = new WWWForm();
        form.AddField("data", query);

        using (UnityWebRequest www = UnityWebRequest.Post("https://overpass-api.de/api/interpreter", form))
        {
            yield return www.SendWebRequest();
            if (www.result != UnityWebRequest.Result.Success) yield break;

            var parsed = JSON.Parse(www.downloadHandler.text);
            var elements = parsed["elements"];
            if (elements == null || elements.Count == 0) yield break;

            double nearestDistSq = double.MaxValue;
            string nearestName = "���O�Ȃ�";
            double nearestLat = 0, nearestLon = 0;

            for (int i = 0; i < elements.Count; i++)
            {
                var node = elements[i];
                double lat = node["lat"];
                double lon = node["lon"];
                string name = (node["tags"] != null && node["tags"]["name"] != null) ? node["tags"]["name"] : "���O�Ȃ�";

                double distSq = GeoCalculator.GetDistanceSquared(nodeLat, nodeLon, lat, lon);
                if (distSq < nearestDistSq)
                {
                    nearestDistSq = distSq;
                    nearestName = name;
                    nearestLat = lat;
                    nearestLon = lon;
                }
            }
            onComplete?.Invoke(nearestLat, nearestLon, nearestName);
        }
    }

    /// <summary>
    /// startLat/Lon: ���ݒn
    /// targetLat/Lon: �ړI�n
    /// </summary>
    public IEnumerator HandleRouteCoroutine(double startLat, double startLon, double targetLat, double targetLon, string name)
    {
        double distance = GeoCalculator.GetDistance(startLat, startLon, targetLat, targetLon);
        double direction = GeoCalculator.GetDirection(startLat, startLon, targetLat, targetLon);

        // GeospatialController �ɖړI�n��z�u�i���p�A���J�[�Ȃǁj
        var geoCtrl = UnityEngine.Object.FindFirstObjectByType<Google.XR.ARCoreExtensions.Samples.Geospatial.GeospatialController>();
        if (geoCtrl != null)
        {
            // ��: PlaceDestinationFromLatLon ���Â����W�n���W�b�N���g���Ă���ꍇ�͏C�����K�v��������܂��񂪁A
            // �����RouteLine����ړI�Ȃ̂ł��̂܂܂ɂ��܂��B
            geoCtrl.PlaceDestinationFromLatLon(targetLon, targetLat, double.NaN, direction);
        }

        string busInfo =
            $"�ړI�n: {name}\n" +
            $"��������: {distance:F1} m\n" +
            $"���W: ({targetLat:F6}, {targetLon:F6})";

        DebugTextManager.Set("BusStop", busInfo);

        if (routeRequest != null)
        {
            // ���C��: ��d�Ăяo�����폜���A�����ł̂݌Ăяo��
            // ���ݒn(start) -> �o�X��(target) �ւ̃��[�g�����N�G�X�g
            yield return StartCoroutine(routeRequest.RequestRouteAndPlace(startLat, startLon, targetLat, targetLon));
        }
    }
}