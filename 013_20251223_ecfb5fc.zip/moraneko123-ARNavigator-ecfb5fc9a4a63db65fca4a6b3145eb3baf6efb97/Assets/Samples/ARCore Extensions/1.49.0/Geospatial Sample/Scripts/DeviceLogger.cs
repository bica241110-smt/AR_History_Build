using Google.XR.ARCoreExtensions.Samples.Geospatial;
using System;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DeviceLogger : MonoBehaviour
{
    public GeospatialController GeospatialController; // �V�[���� GeospatialController ���A�T�C���\
    public TextMeshProUGUI OnScreenLogText;                      // �C�ӂ� UI Text�iInspector �Ŋ����āj
    public bool AppendToFile = true;
    public string FileName = "device_log.txt";
    private string _filePath;

    void Awake()
    {
        _filePath = Path.Combine(Application.persistentDataPath, FileName);
        Debug.Log($"DeviceLogger: log file path = {_filePath}");
    }

    void OnEnable()
    {
        Application.logMessageReceived += HandleLog;
    }

    void OnDisable()
    {
        Application.logMessageReceived -= HandleLog;
    }

    private void HandleLog(string logString, string stackTrace, LogType type)
    {
        string time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
        string line = $"[{time}][{type}] {logString}";
        if (!string.IsNullOrEmpty(stackTrace))
        {
            line += "\n" + stackTrace;
        }

        // ��ʏo�́i�D�揇��: �����I�� OnScreenLogText -> GeospatialController.DebugText -> �����j
        if (OnScreenLogText != null)
        {
            OnScreenLogText.text = GetLogFilePath();
            // prepend �ŐV�s�����
            //OnScreenLogText.text = line + "\n\n" + OnScreenLogText.text;
            // �ߏ�Ȓ��������
            //if (OnScreenLogText.text.Length > 20000) OnScreenLogText.text = OnScreenLogText.text.Substring(0, 20000);
        }
        else if (GeospatialController != null && GeospatialController.DebugText != null)
        {
            GeospatialController.DebugText.text = line + "\n\n" + GeospatialController.DebugText.text;
        }

        // �t�@�C���ǋL
        if (AppendToFile)
        {
            try
            {
                File.AppendAllText(_filePath, line + Environment.NewLine + Environment.NewLine);
            }
            catch (Exception)
            {
                // �t�@�C���������ݎ��s�͂����ł͖����i�ċA���O�h�~�j
            }
        }
    }

    // ���O�t�@�C���̃p�X�擾�i�f�o�b�O�p�j
    public string GetLogFilePath() => _filePath;
}