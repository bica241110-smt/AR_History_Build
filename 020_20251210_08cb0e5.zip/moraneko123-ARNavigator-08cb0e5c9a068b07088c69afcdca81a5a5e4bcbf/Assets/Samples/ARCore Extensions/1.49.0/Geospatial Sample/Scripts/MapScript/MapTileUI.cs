using Google.XR.ARCoreExtensions.Samples.Geospatial;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;

public class MapTileUI : MonoBehaviour
{
    [Header("UI Components")]
    public RawImage mapImage;  // �� Canvas ��� RawImage ���w��
    public RouteDrawer routeDrawer;
    public int zoom = 15;
    private int tileX, tileY;
    public TextMeshProUGUI debugText;
    private Vector2Int osmVec;

    public IEnumerator LoadMapTile(double tileX, double tileY)
    {
        yield return new WaitForSecondsRealtime(1);

        osmVec = LatLonToTile(tileX, tileY, zoom);
        debugText.text = $"TileX: {osmVec.x}, TileY: {osmVec.y}";
        string url = $"https://tile.openstreetmap.org/{zoom}/{osmVec.x}/{osmVec.y}.png";
        using (UnityWebRequest req = UnityWebRequestTexture.GetTexture(url))
        {
            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success)
            {
                Texture2D tex = DownloadHandlerTexture.GetContent(req);
                if (tex != null)
                {
                    if (mapImage != null)
                    {
                        mapImage.texture = tex;
                        mapImage.uvRect = new Rect(0, 0, 1, 1);
                        mapImage.enabled = true;
                        Debug.Log("Map tile loaded and applied to RawImage.");
                    }
                    else
                    {
                        Debug.LogError("mapImage is not assigned in the Inspector.");
                    }
                }
                else
                {
                    Debug.LogError("Download returned null texture.");
                }
            }
            else
            {
                long code = req.responseCode;
                Debug.LogError($"Failed to load map tile: {req.error}, responseCode: {code}");
            }
        }
    }

    public void ShowRoute(List<Vector2> latLonPoints)
    {
        List<Vector2> uiPoints = new List<Vector2>();

        foreach (var latlon in latLonPoints)
        {
            var px = LatLonToPixel(latlon.x, latlon.y);
            uiPoints.Add(px);
        }

        routeDrawer.SetRoute(uiPoints);
    }

    public Vector2Int LatLonToTile(double lat, double lon, int zoom)
    {
        double latRad = lat * Mathf.Deg2Rad;
        double n = Math.Pow(2.0, zoom);
        double x = (lon + 180.0) / 360.0 * n;
        double y = (1.0 - Math.Log(Math.Tan(latRad) + 1.0 / Math.Cos(latRad)) / Math.PI) / 2.0 * n;
        int tileXInt = (int)Math.Floor(x);
        int tileYInt = (int)Math.Floor(y);
        return new Vector2Int(tileXInt, tileYInt);
    }

    // �C���F�^�C�����̃s�N�Z�����W�i���ݕ\�����̃^�C�������_�ɂ���UI���W�j��Ԃ�
    public Vector2 LatLonToPixel(double lat, double lon)
    {
        int tileSize = 256;

        double latRad = lat * Mathf.Deg2Rad;
        double n = Math.Pow(2.0, zoom);

        double xf = (lon + 180.0) / 360.0 * n; // �^�C���P�ʁi�����_�܂ށj
        double yf = (1.0 - Math.Log(Math.Tan(latRad) + 1.0 / Math.Cos(latRad)) / Math.PI) / 2.0 * n;

        double pixelXGlobal = xf * tileSize;
        double pixelYGlobal = yf * tileSize;

        // ���ݕ\�����Ă���^�C���̍���O���[�o���s�N�Z�����W
        double originX = tileX * tileSize;
        double originY = tileY * tileSize;

        // UI���W�n��Y���]�i�K�v�ɉ����Ē����j
        float dx = (float)(pixelXGlobal - originX);
        float dy = (float)(originY - pixelYGlobal);

        return new Vector2(dx, dy);
    }
}
