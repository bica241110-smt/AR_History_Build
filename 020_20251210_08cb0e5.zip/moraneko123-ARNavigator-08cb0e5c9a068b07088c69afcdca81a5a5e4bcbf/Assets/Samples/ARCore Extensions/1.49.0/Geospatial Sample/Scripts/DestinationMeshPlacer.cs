using Google.XR.ARCoreExtensions;
using Google.XR.ARCoreExtensions.Samples.Geospatial;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class DestinationMeshPlacer : MonoBehaviour
{
    public GeospatialController GeospatialController;
    public GameObject DestinationPrefab;
    public GameObject CornerPrefab;

    [Tooltip("�n�ʂ���̍����I�t�Z�b�g (��: 0�Ȃ�n�ʁA0.2�Ȃ班������)")]
    public float AltitudeOffset = 0f;

    public float ScaleFactorPerMeter = 0.1f;
    public RouteLineRenderer routeLineRenderer;

    // --- ���W�ϊ��p ---
    const double EarthRadius = 6378137.0;

    private double cameraAltitude;
    private double useAltitude;

    // --- ���I�����p�̐ݒ� ---
    [Header("Dynamic Route Settings")]
    public RouteProgressMonitor progressMonitor;
    public const int MAX_ACTIVE_ANCHORS = 20;

    private List<Vector2> _fullRoutePath;
    private LinkedList<GameObject> _activeAnchors = new LinkedList<GameObject>();
    private int _nextSpawnIndex = 0;

    private ARGeospatialAnchor _lineBaseAnchor;

    // �X�}�z�������Ă��鍂���̖ڈ� (m)
    private const float DEVICE_HEIGHT_OFFSET = 1.5f;

    private void Awake()
    {
        if (GeospatialController == null)
            DebugTextManager.Set("Destination", "GeospatialController ���ݒ�");

        if (DestinationPrefab == null)
            DebugTextManager.Set("Destination", "DestinationPrefab ���ݒ�");
    }

    // =====================================================================
    // ���b�V���z�u�F�P��̈ܓx�o�x�ɃA���J�[�{�v���n�u��z�u
    // =====================================================================
    public GameObject PlaceDestination(double latitude, double longitude, double altitude = double.NaN, double heading = 0.0, bool isCorner = false, Action<GameObject> onAsyncComplete = null)
    {
        if (GeospatialController == null || GeospatialController.EarthManager == null || GeospatialController.AnchorManager == null)
            return null;

        var earthManager = GeospatialController.EarthManager;
        cameraAltitude = earthManager.CameraGeospatialPose.Altitude;
        useAltitude = double.IsNaN(altitude) ? cameraAltitude : altitude;

        // AltitudeOffset �݂̂��Ɓu�ڂ̍����v�ɂȂ邽�߁ADEVICE_HEIGHT_OFFSET �������āu�����v�ɂ���
        // �� ResolveAnchorOnTerrainAsync (�n�`) �ƍ��������킹�邽��
        double targetAltitude = useAltitude + AltitudeOffset - DEVICE_HEIGHT_OFFSET;

        Quaternion rot = Quaternion.AngleAxis((float)heading, Vector3.up);

        // �܂��͒ʏ��AddAnchor�iGPS���x�x�[�X�j�����݂�
        var anchor = GeospatialController.AnchorManager.AddAnchor(latitude, longitude, targetAltitude, rot);

        if (anchor != null)
        {
            InstantiateUnderAnchor(anchor.gameObject, isCorner);
            return anchor.gameObject;
        }
        else
        {
            // ���s������Terrain�i�n�`�f�[�^�j�x�[�X�����݂�
            StartCoroutine(ResolveOnTerrainRoutine(latitude, longitude, rot, isCorner, onAsyncComplete));
            return null;
        }
    }

    private void InstantiateUnderAnchor(GameObject anchorGO, bool isCorner = false)
    {
        if (DestinationPrefab == null || anchorGO == null) return;

        var prefab = (isCorner && CornerPrefab != null) ? CornerPrefab : DestinationPrefab;

        var go = Instantiate(prefab, anchorGO.transform);
        go.transform.SetParent(anchorGO.transform, false);
        go.transform.localPosition = Vector3.zero;
        go.transform.localRotation = Quaternion.identity;

        // �X�P�[������
        Vector3 camPos = Camera.main ? Camera.main.transform.position : Vector3.zero;
        float scale = GetScaleForDistance(anchorGO.transform.position, camPos);
        go.transform.localScale = Vector3.one * scale;

        // �A�N�e�B�u����Renderer�m�F
        if (!go.activeInHierarchy) go.SetActive(true);

        var rend = go.GetComponentInChildren<Renderer>();
        if (rend != null && !rend.enabled) rend.enabled = true;
    }

    private IEnumerator ResolveOnTerrainRoutine(double lat, double lon, Quaternion rot, bool isCorner, Action<GameObject> onComplete)
    {
        // TerrainAnchor�́u�n�ʂ̍����v�ɔz�u����邽�߁AAltitudeOffset�̂݉��Z����iDEVICE_HEIGHT_OFFSET�͕s�v�j
        // ���n��(0) + Offset 
        var promise = GeospatialController.AnchorManager.ResolveAnchorOnTerrainAsync(lat, lon, AltitudeOffset, rot);
        yield return promise;

        var result = promise.Result;
        if (result.TerrainAnchorState == TerrainAnchorState.Success && result.Anchor != null)
        {
            InstantiateUnderAnchor(result.Anchor.gameObject, isCorner);
            onComplete?.Invoke(result.Anchor.gameObject);
        }
        else
        {
            onComplete?.Invoke(null);
        }
    }

    private float GetScaleForDistance(Vector3 anchorPos, Vector3 camPos)
    {
        float dist = Vector3.Distance(anchorPos, camPos);
        return Mathf.Clamp(dist * ScaleFactorPerMeter, 0.1f, 10f);
    }

    // =====================================================================
    // ���[�g�J�n�E�Ǘ�
    // =====================================================================

    public void StartDynamicRoute(List<Vector2> routePoints)
    {
        if (routePoints == null || routePoints.Count == 0) return;
        if (progressMonitor == null)
        {
            Debug.LogError("RouteProgressMonitor ���ݒ肳��Ă��܂���I");
            return;
        }

        // ���ǉ�: �����̃��[�g���C����A���J�[���m���Ƀ��Z�b�g
        ClearCurrentRoute();

        // ������
        _fullRoutePath = routePoints;
        _nextSpawnIndex = 0;

        progressMonitor.OnTargetReached -= OnNextAnchorReached;
        progressMonitor.OnTargetReached += OnNextAnchorReached;

        // �ŏ��̃o�b�`�𐶐�
        int initialCount = Mathf.Min(MAX_ACTIVE_ANCHORS, _fullRoutePath.Count);
        for (int i = 0; i < initialCount; i++)
        {
            SpawnNextAnchor();
        }

        UpdateMonitorTarget();

        // ���[�g���C���`��J�n
        var earthManager = GeospatialController.EarthManager;
        var pose = earthManager.CameraGeospatialPose;
        StartCoroutine(DrawRouteLineFromPositions(routePoints, pose.Latitude, pose.Longitude, pose.Altitude, 1, double.NaN));
    }

    private void OnNextAnchorReached()
    {
        // �ʉ߂����A���J�[���폜
        if (_activeAnchors.Count > 0)
        {
            GameObject passedAnchor = _activeAnchors.First.Value;
            _activeAnchors.RemoveFirst();
            if (passedAnchor != null) Destroy(passedAnchor);
        }

        // ���̃A���J�[�𐶐�
        SpawnNextAnchor();
        UpdateMonitorTarget();
    }

    private void SpawnNextAnchor()
    {
        if (_fullRoutePath == null || _nextSpawnIndex >= _fullRoutePath.Count) return;

        Vector2 p = _fullRoutePath[_nextSpawnIndex];

        // �R�[���o�b�N�t���Ő���
        GameObject newAnchor = PlaceDestination(p.y, p.x, double.NaN, 0.0, false, (asyncAnchor) =>
        {
            if (asyncAnchor != null)
            {
                _activeAnchors.AddLast(asyncAnchor);
                if (_activeAnchors.Count == 1) UpdateMonitorTarget();
            }
        });

        if (newAnchor != null)
        {
            _activeAnchors.AddLast(newAnchor);
        }

        _nextSpawnIndex++;
    }

    private void UpdateMonitorTarget()
    {
        if (_activeAnchors.Count > 0 && _activeAnchors.First.Value != null)
        {
            progressMonitor.SetTarget(_activeAnchors.First.Value.transform);
        }
        else
        {
            progressMonitor.StopMonitoring();
        }
    }

    // =====================================================================
    // ���Z�b�g����
    // =====================================================================
    public void ClearCurrentRoute()
    {
        // 1. LineRenderer �̌�n��
        if (routeLineRenderer != null)
        {
            routeLineRenderer.transform.SetParent(null); // �e����O��
            routeLineRenderer.gameObject.SetActive(false);

            var lr = routeLineRenderer.GetComponent<LineRenderer>();
            if (lr != null)
            {
                lr.positionCount = 0;
                lr.enabled = false;
            }
        }

        // 2. ��A���J�[�j��
        if (_lineBaseAnchor != null)
        {
            Destroy(_lineBaseAnchor.gameObject);
            _lineBaseAnchor = null;
        }

        // 3. �}�[�J�[���X�g�j��
        ClearActiveAnchors();

        DebugTextManager.Log("Route", "���[�g�������Z�b�g�����B");
    }

    public void ClearActiveAnchors()
    {
        foreach (var anchor in _activeAnchors)
        {
            if (anchor != null) Destroy(anchor);
        }
        _activeAnchors.Clear();
        if (progressMonitor != null) progressMonitor.StopMonitoring();
    }

    // =====================================================================
    // LineRenderer (�Œ��)
    // =====================================================================
    private IEnumerator DrawRouteLineFromPositions(List<Vector2> routePoints, double baseLat, double baseLon, double baseAlt, int step, double altitude)
    {
        if (routePoints == null || routePoints.Count < 2) yield break;
        if (GeospatialController.AnchorManager == null) yield break;
        if (routeLineRenderer == null) yield break;

        // ��A���J�[�쐬 (���[�g�n�_)
        var baseAnchor = GeospatialController.AnchorManager.AddAnchor(baseLat, baseLon, baseAlt, Quaternion.identity);

        if (baseAnchor == null)
        {
            DebugTextManager.Log("Destination", "LineRenderer��A���J�[�������s");
            yield break;
        }

        yield return new WaitForEndOfFrame();
        _lineBaseAnchor = baseAnchor;

        // �A���J�[�̎q�ɂ��� (�ʒu�Œ�̊�)
        routeLineRenderer.transform.SetParent(baseAnchor.transform, false);
        routeLineRenderer.transform.localPosition = Vector3.zero;
        routeLineRenderer.transform.localRotation = Quaternion.identity;

        List<Vector3> localPositions = new List<Vector3>();
        double baseLatRad = baseLat * Mathf.Deg2Rad;

        for (int i = 0; i < routePoints.Count; i += step)
        {
            Vector2 p = routePoints[i];

            // �ܓx�o�x�����v�Z
            double dLat = (p.y - baseLat) * Mathf.Deg2Rad;
            double dLon = (p.x - baseLon) * Mathf.Deg2Rad;

            double x = EarthRadius * dLon * Math.Cos(baseLatRad);
            double z = EarthRadius * dLat;

            // �������u�����v�ɂ���
            // �A���J�[(��) - 1.5m = �n��
            float y = AltitudeOffset - DEVICE_HEIGHT_OFFSET;

            localPositions.Add(new Vector3((float)x, y, (float)z));
        }

        if (localPositions.Count > 1)
        {
            if (!routeLineRenderer.gameObject.activeInHierarchy)
                routeLineRenderer.gameObject.SetActive(true);

            routeLineRenderer.DrawRouteLocal(localPositions);
            DebugTextManager.Log("Destination", $"���[�g���C���`��: {localPositions.Count}�_");
        }
    }
}