using TMPro;
using UnityEngine;

public class AutoFontSizeAdjuster : MonoBehaviour
{
    public TMP_Text text;
    public RectTransform container;

    void Start()
    {
        AdjustFontSize();
    }

    void AdjustFontSize()
    {
        if (text == null || container == null) return;

        float containerWidth = container.rect.width;
        float containerHeight = container.rect.height;

        text.enableAutoSizing = true;
        text.fontSizeMin = 14f;
        text.fontSizeMax = 24f;

        // �I�v�V�����F���������܂�Ȃ��ꍇ�͏k��
        text.rectTransform.sizeDelta = new Vector2(containerWidth, containerHeight);
        text.ForceMeshUpdate();
    }
}