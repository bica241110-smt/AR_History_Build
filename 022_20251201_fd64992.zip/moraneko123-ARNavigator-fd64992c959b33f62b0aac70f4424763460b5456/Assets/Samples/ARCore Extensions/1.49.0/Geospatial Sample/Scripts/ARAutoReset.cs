//using UnityEngine;
//using UnityEngine.XR.ARFoundation;

//public class ARAutoReset : MonoBehaviour
//{
//    public float timeoutSeconds = 10f;
//    float timer;

//    void Update()
//    {
//        if (ARSession.state == ARSessionState.SessionTracking)
//        {
//            timer = 0f;
//            return;
//        }

//        // Tracking���Ă��Ȃ��ԃ^�C�}�[��i�߂�
//        timer += Time.deltaTime;
//        if (timer > timeoutSeconds)
//        {
//            timer = 0f;
//            StartCoroutine(ResetSession());
//        }
//    }

//    System.Collections.IEnumerator ResetSession()
//    {
//        ARSession.stateChanged += OnStateChanged;
//        ARSession.Reset();
//        yield return null;
//    }

//    void OnStateChanged(ARSessionStateChangedEventArgs args)
//    {
//        if (args.state == ARSessionState.SessionTracking)
//        {
//            ARSession.stateChanged -= OnStateChanged;
//            // ���A����
//        }
//    }
//}